#!/usr/bin/env python
"""
File: task_manager.py
Description: Instance a TaskManager and monitor the peak memory and CPU usage during the operation of the task.
CreateDate: 2023/9/8
Author: xuwenlin
E-mail: wenlinxu.njfu@outlook.com
"""
from typing import Union, Tuple, Iterable, Callable
from time import time
from datetime import datetime
from os import getcwd, getpid
from getpass import getuser
from socket import gethostname
from threading import Event, Thread
import multiprocessing
from subprocess import run, PIPE
from psutil import AccessDenied, NoSuchProcess, Process
import traceback
from click import echo


class LogExceptions(object):
    """Capture and record any exceptions occurring within the called function."""

    def __init__(self, callable_func):
        self.__callable = callable_func

    def __call__(self, *args, **kwargs):
        try:
            return self.__callable(*args, **kwargs)
        except Exception as e:
            # Obtain the logger of the multiprocess module and record the error
            logger = multiprocessing.get_logger()
            logger.error(traceback.format_exc())
            raise


class TaskManager:
    def __init__(
        self,
        commands: Iterable[str] = None,
        num_processing: int = None,
        params: Iterable[tuple] = None
    ):
        try:
            self.task = list(commands)
        except TypeError:
            self.task = []
        self.params = params
        self.num_processing = num_processing

    def add_task(self, command: Union[str, Iterable[str]]):
        if isinstance(command, str):
            self.task.append(command)
        else:
            command = list(command)
            self.task.extend(command)

    def del_task(self, index: Union[int, str] = None):
        if isinstance(index, int):
            del self.task[index]
        elif isinstance(index, str):
            self.task.remove(index)
        else:
            self.task.pop()

    def clear_task(self):
        self.task = []

    @staticmethod
    def echo_and_exec_cmd(cmd: str, show_cmd: bool = True, pipe: bool = True) -> Tuple[str, str]:
        if show_cmd:
            echo(
                message=(
                    f'\033[35;1m{getuser()}@{gethostname()}\033[0m '
                    f'\033[32;1m{datetime.now().replace(microsecond=0)}\033[0m '
                    f'\033[34;1m{getcwd()}\033[0m\n'
                    f'\033[33;1m$\033[0m \033[1m{cmd}\033[0m\n'
                ),
                err=True
            )
        if pipe:
            ret = run(cmd, shell=True, executable="/bin/bash", stdout=PIPE, stderr=PIPE)
            stdout, stderr = ret.stdout.decode('utf8'), ret.stderr.decode('utf8')
            return stdout, stderr
        else:
            run(cmd, shell=True, executable="/bin/bash")
            return '', ''

    def serial_run_cmd(self, show_cmd: bool = True, pipe: bool = False) -> list:
        results = [
            self.echo_and_exec_cmd(cmd=cmd, show_cmd=show_cmd, pipe=pipe)
            for cmd in self.task
        ]
        return results

    def parallel_run_cmd(self, show_cmd: bool = True, pipe: bool = False) -> list:
        if not self.task:
            echo('\033[31mError: TaskManager has no task.\033[0m', err=True)
            exit()
        results = []
        with multiprocessing.Pool(self.num_processing) as pool:
            for cmd in self.task:
                ret = pool.apply_async(self.echo_and_exec_cmd, args=(cmd, show_cmd, pipe))
                results.append(ret)
            pool.close()
            pool.join()
        return results

    def parallel_run_func(self, func: Callable, call_back_func: Callable = None) -> list:
        results = []
        with multiprocessing.Pool(self.num_processing) as pool:
            for param in self.params:
                ret = pool.apply_async(
                    LogExceptions(func),
                    args=param,
                    callback=call_back_func
                )
                results.append(ret)
            pool.close()
            pool.join()
        return results


class ResourceMonitor:
    def __init__(self, pid=None, interval=0.5):
        """
        :param pid: The root process PID to be monitored defaults to the current process
        :param interval: Sampling interval (seconds)
        """
        self.pid = pid or getpid()
        self.interval = interval
        self._stop_event = Event()
        self._thread = None

        self.peak_memory = 0
        self.peak_cpu_percent = 0.0

        self._last_times = {}
        self._last_wall_time = time()

    @staticmethod
    def _get_process_tree(proc):
        processes = [proc]
        try:
            children = proc.children(recursive=True)
            processes.extend(children)
        except (NoSuchProcess, AccessDenied):
            pass
        return processes

    def _sample(self):
        try:
            root_proc = Process(self.pid)
        except NoSuchProcess:
            return

        all_procs = self._get_process_tree(root_proc)

        total_mem = 0
        for p in all_procs:
            try:
                mem = p.memory_info().rss
                total_mem += mem
            except (NoSuchProcess, AccessDenied):
                continue
        if total_mem > self.peak_memory:
            self.peak_memory = total_mem

        now = time()
        wall_delta = now - self._last_wall_time
        if wall_delta <= 0:
            return

        total_cpu_percent = 0.0
        current_times = {}
        for p in all_procs:
            try:
                cpu_times = p.cpu_times()
                total_time = cpu_times.user + cpu_times.system
                current_times[p.pid] = total_time
            except (NoSuchProcess, AccessDenied):
                continue

        for pid, cur_time in current_times.items():
            last = self._last_times.get(pid)
            if last is not None:
                delta = cur_time - last
                percent = (delta / wall_delta) * 100.0
                total_cpu_percent += percent

        if total_cpu_percent > self.peak_cpu_percent:
            self.peak_cpu_percent = total_cpu_percent

        self._last_times = current_times
        self._last_wall_time = now

    def _monitor_loop(self):
        try:
            root_proc = Process(self.pid)
            all_procs = self._get_process_tree(root_proc)
            for p in all_procs:
                try:
                    cpu_times = p.cpu_times()
                    self._last_times[p.pid] = cpu_times.user + cpu_times.system
                except Exception as e1:
                    echo(e1, err=True)
            self._last_wall_time = time()
        except Exception as e2:
            echo(e2, err=True)

        while not self._stop_event.wait(self.interval):
            self._sample()

    def start(self):
        if self._thread is not None:
            return
        self._stop_event.clear()
        self._thread = Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()

    def stop(self):
        if self._thread is None:
            return self.peak_memory, self.peak_cpu_percent
        self._stop_event.set()
        self._thread.join()
        self._thread = None
        self._sample()
        return self.peak_memory, self.peak_cpu_percent


def test():
    monitor = ResourceMonitor(interval=0.5)
    monitor.start()

    tkm = TaskManager()
    cmds = [f'echo Hello World x {i}' for i in range(100)]
    tkm.add_task(cmds)
    rets = tkm.serial_run_cmd(show_cmd=True, pipe=False)
    for res in rets:
        stdout, stderr = res
        if stdout:
            echo(stdout)
        if stderr:
            echo(stderr, err=True)

    peak_mem, peak_cpu = monitor.stop()
    peak_mem = peak_mem / 1024 ** 3
    if peak_mem <= 1:
        peak_mem = "%.2f MB" % (peak_mem * 1024)
    else:
        peak_mem = "%.2f GB" % peak_mem
    echo(f"\n\033[32mPeak memory consumption: {peak_mem}\033[0m", err=True)
    echo(f"\033[32mPeak CPU usage rate: {peak_cpu:.2f}% (relative to a single core)\033[0m", err=True)


if __name__ == '__main__':
    test()
