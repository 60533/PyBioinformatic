from pybioinformatic.bed import Bed
from pybioinformatic.biomysql import BioMySQL
from pybioinformatic.blast import Blast
from pybioinformatic.check_yml import is_valid_file, is_valid_directory, is_writable, check_config
from pybioinformatic.decompressing_file import ungz
from pybioinformatic.fasta import Fasta
from pybioinformatic.fastq import Fastq
from pybioinformatic.genotype import GenoType
from pybioinformatic.gff import Gff
from pybioinformatic.gtf import Gtf
from pybioinformatic.sequence import Sequence, Nucleotide, Protein, Reads
from pybioinformatic.show_info import Displayer
from pybioinformatic.task_manager import TaskManager, ResourceMonitor
from pybioinformatic.timer import Timer
from pybioinformatic.util import FuncDict
from pybioinformatic.vcf import VCF

from pybioinformatic.NGS import (
    check_cmds,
    check_R_packages,
    parse_sample_info,
    build_ref_index,
    NGSAnalyser,
    GatkSNPCalling,
    Macs2PeakCalling,
    AllelicExpressionAnalyzer,
    RNASeqAnalysisWithReference,
    LncRNAPredictor,
    LncRNATargetPredictor,
    LncRNAClassification
)

from pybioinformatic.biopandas import (
    display_set,
    read_file_as_df_from_stdin,
    merge_duplicate_indexes,
    filter_by_min_value,
    get_FPKM,
    get_TPM,
    dfs_to_excel,
    dataframe_to_str,
    interval_stat
)

from pybioinformatic.biomatplotlib import (
    set_custom_font,
    generate_unique_colors,
    format_xticks_by_kmg,
    rotate_ax_tick_labels
)


__version__ = '1.2.7a'

__all__ = [
    # biofile
    'Bed', 'Blast', 'Fasta', 'Fastq', 'GenoType', 'Gff', 'Gtf', 'ungz', 'VCF',

    # config file
    'check_config', 'is_valid_file', 'is_valid_directory', 'is_writable',

    # NGS pipeline
    'check_cmds', 'check_R_packages', 'parse_sample_info', 'build_ref_index',
    'NGSAnalyser', 'GatkSNPCalling', 'Macs2PeakCalling',
    'RNASeqAnalysisWithReference', 'LncRNAPredictor', 'LncRNATargetPredictor', 'LncRNAClassification',
    'AllelicExpressionAnalyzer',

    # bioseq
    'Sequence', 'Nucleotide', 'Protein', 'Reads',

    # pandas
    'display_set', 'read_file_as_df_from_stdin', 'merge_duplicate_indexes', 'filter_by_min_value',
    'get_TPM', 'get_FPKM', 'dfs_to_excel', 'dataframe_to_str', 'interval_stat',

    # plot
    'format_xticks_by_kmg', 'generate_unique_colors', 'rotate_ax_tick_labels', 'set_custom_font',

    # others
    'BioMySQL', 'Displayer', 'FuncDict', 'Timer', 'TaskManager', 'ResourceMonitor',
]
