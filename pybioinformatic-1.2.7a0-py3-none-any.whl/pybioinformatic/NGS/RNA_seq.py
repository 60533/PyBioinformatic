"""
File: RNA_seq.py
Description: RNA-seq analysis pipeline module.
CreateDate: 2024/7/24
Author: xuwenlin
E-mail: wenlinxu.njfu@outlook.com
"""
from io import TextIOWrapper
from typing import Literal, Union, Dict, List, Tuple
from collections import defaultdict
from os import makedirs
from os.path import abspath, exists
from shutil import which
from tqdm import tqdm
from natsort import natsort_key
from numpy import ndarray, mean, median, std, sqrt, log2, nan, concatenate, abs, unique, linspace, argsort, pi, where
from pandas import read_csv, DataFrame, Series, concat
from scipy.stats import pearsonr, ttest_rel, wilcoxon, ttest_ind, spearmanr, mannwhitneyu
from statsmodels.stats.multitest import multipletests
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
from sklearn.metrics import silhouette_score, calinski_harabasz_score
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from click.utils import LazyFile
from pybioinformatic.biopandas import filter_by_min_value, dfs_to_excel
from pybioinformatic.gtf import Gtf
from pybioinformatic.task_manager import TaskManager
from pybioinformatic.NGS import NGSAnalyser
from pybioinformatic.util import FuncDict


class AllelicExpressionAnalyzer:
    """
    Allelic expression analyzer.

    Parameters:
        -----------
        allele_exp_file: Allele expression matrix file
                        (row: allele, column: sample)
        allele_pairs_file: Allele pair information file
                          (column 1: loci ID, column 2: allele 1, column 3: allele 2)
        num_processing: Number of processing
    """
    def __init__(
        self,
        allele_exp_file: Union[str, TextIOWrapper],
        allele_pairs_file: Union[str, TextIOWrapper],
        num_processing: int = 10
    ):
        self.pairwise_features = None
        self.clustering_results = None
        self.differential_results = {}
        self.num_processing = num_processing
        self.allele_exp = read_csv(allele_exp_file, sep='\t', index_col=0)
        self.allele_pairs = defaultdict(list)  # {loci_id: [allele1, allele2], ...}
        if isinstance(allele_pairs_file, str):
            with open(allele_pairs_file) as f:
                for line in f:
                    if line.strip():
                        split = line.strip().split('\t')
                        loci_id, allele1, allele2 = split
                        self.allele_pairs[loci_id] = [allele1, allele2]
        elif isinstance(allele_pairs_file, TextIOWrapper):
            for line in allele_pairs_file:
                if line.strip():
                    split = line.strip().split('\t')
                    loci_id, allele1, allele2 = split
                    self.allele_pairs[loci_id] = [allele1, allele2]

# Allele expression pattern clustering=====================================================================================
    def _calculate_pairwise_features(
        self,
        exp1: ndarray,
        exp2: ndarray
    ) -> Dict:
        """
        Calculate multiple features of allele pairs.

        Parameters:
        -----------
        exp1: The expression vector of allele 1
        exp2: The expression vector of allele 2

        Returns:
        --------
        Dict: A dictionary containing various eigenvalues
        """
        # 1. basic statistical features
        features = {
            'mean_ratio': mean(exp1) / (mean(exp2) + 1e-10),
            'median_ratio': median(exp1) / (median(exp2) + 1e-10)
        }

        # 2. correlation features
        if len(exp1) > 1:
            features['pearson_corr'] = pearsonr(exp1, exp2)[0]
            features['spearman_corr'] = spearmanr(exp1, exp2)[0]
        else:
            features['pearson_corr'] = nan
            features['spearman_corr'] = nan

        # 3. differential expression features
        features['fold_change'] = log2((mean(exp1) + 1e-10) / (mean(exp2) + 1e-10))

        # T-test statistics (without assuming homogeneity of variance)
        if len(exp1) > 1 and len(exp2) > 1:
            t_stat, p_value = ttest_ind(exp1, exp2, equal_var=False)
            features['t_statistic'] = t_stat
            features['ttest_pvalue'] = p_value
        else:
            features['t_statistic'] = nan
            features['ttest_pvalue'] = nan

        # 4. variability characteristics
        features['cv_ratio'] = (std(exp1) / (mean(exp1) + 1e-10)) / \
                               (std(exp2) / (mean(exp2) + 1e-10))

        # 5. Combined features (concatenated expression vectors)
        features['combined_mean'] = mean(concatenate([exp1, exp2]))
        features['combined_std'] = std(concatenate([exp1, exp2]))

        # 6. Relative expression pattern characteristics
        features['dominance'] = mean(exp1 > exp2)
        features['expression_balance'] = abs(features['fold_change'])

        return features

    def preprocess_data(
        self,
        min_expression: float = 1.0,
        min_samples: int = 3
    ) -> None:
        """
        Preprocessing data: Filter out low-expression alleles and construct an allele pair feature matrix

        Parameters:
        -----------
        min_expression: Minimum expression value threshold
        min_samples: How many samples at least need to be expressed

        Returns:
        --------
        pd.DataFrame: Allele pair feature matrix
        """
        # Filter out low-expression alleles
        mask = (self.allele_exp > min_expression).sum(axis=1) >= min_samples
        filtered_exp = self.allele_exp[mask]

        # Construct allele pair features
        pairwise_data = []

        for loci_id, alleles in self.allele_pairs.items():
            allele1, allele2 = alleles
            if allele1 in filtered_exp.index and allele2 in filtered_exp.index:
                exp1 = filtered_exp.loc[allele1].values
                exp2 = filtered_exp.loc[allele2].values

                # Calculate the features of multiple allele pairs
                features = self._calculate_pairwise_features(exp1, exp2)
                features['loci_id'] = loci_id
                features['allele1'] = allele1
                features['allele2'] = allele2

                pairwise_data.append(features)

        self.pairwise_features = DataFrame(pairwise_data)
        self.pairwise_features.set_index('loci_id', inplace=True)

    def clustering(
        self,
        method: Literal['kmeans', 'hierarchical', 'dbscan', 'agglomerative'] = 'kmeans',
        n_clusters: int = 4,
        features_to_use: List[str] = None,
        **kwargs
    ) -> None:
        """
        Alleles expression patterns clustering.

        Parameters:
        -----------
        method: Clustering method ('kmeans', 'hierarchical', 'dbscan', 'agglomerative')
        n_clusters: Number of clusters (it is only applicable to methods that require specifying the number of clusters)
        features_to_use: A list of features for clustering
        **kwargs: Additional parameters passed to the clustering algorithm

        Returns:
        --------
        Dict: A dictionary containing the clustering results
        """
        if self.pairwise_features is None:
            raise ValueError('Please run "preprocess_data()" method first.')

        if features_to_use is None:
            features_to_use = ['mean_ratio', 'fold_change', 'pearson_corr', 't_statistic', 'dominance']

        X = self.pairwise_features[features_to_use].copy()
        X = X.fillna(X.mean())
        X_scaled = StandardScaler().fit_transform(X)

        if method == 'kmeans':
            clusterer = KMeans(n_clusters=n_clusters, random_state=42, **kwargs)
        elif method == 'hierarchical':
            clusterer = AgglomerativeClustering(n_clusters=n_clusters, linkage='ward', **kwargs)
        elif method == 'dbscan':
            clusterer = DBSCAN(**kwargs)
        elif method == 'agglomerative':
            clusterer = AgglomerativeClustering(n_clusters=n_clusters, **kwargs)
        else:
            raise ValueError(f"Unsupported clustering methods: {method}")

        labels = clusterer.fit_predict(X_scaled)

        # Calculate the clustering quality index (only when the number of clusters is greater than 1)
        unique_labels = unique(labels)
        n_clusters_found = len(unique_labels[unique_labels != -1])

        quality_metrics = {}
        if n_clusters_found > 1:
            try:
                quality_metrics['silhouette_score'] = silhouette_score(
                    X_scaled[labels != -1], labels[labels != -1]
                )
            except:
                quality_metrics['silhouette_score'] = nan

            try:
                quality_metrics['calinski_harabasz_score'] = calinski_harabasz_score(
                    X_scaled[labels != -1], labels[labels != -1]
                )
            except:
                quality_metrics['calinski_harabasz_score'] = nan

        self.pairwise_features[f'{method}_cluster'] = labels
        self.clustering_results = {
            'method': method,
            'labels': labels,
            'n_clusters': n_clusters_found,
            'features_used': features_to_use,
            'quality_metrics': quality_metrics,
            'cluster_centers': getattr(clusterer, 'cluster_centers_', None),
            'model': clusterer
        }

    def visualize_clusters(
        self,
        method: Literal['pca', 'tsne'] = 'pca',
        figsize: Tuple[int, int] = (12, 10),
        out_file: str = 'clustering_results.pdf'
    ):
        """
        Visualize the clustering results

        Parameters:
        -----------
        method: Descending dimension method ('pca', 'tsne')
        figsize: Figure size
        """
        if self.clustering_results is None:
            raise ValueError('Please run "clustering()" method first.')

        cluster_col = f"{self.clustering_results['method']}_cluster"
        labels = self.pairwise_features[cluster_col].values

        features_used = self.clustering_results['features_used']
        X = self.pairwise_features[features_used].fillna(
            self.pairwise_features[features_used].mean()
        )
        X_scaled = StandardScaler().fit_transform(X)

        if method == 'pca':
            reducer = PCA(n_components=2, random_state=42)
            X_reduced = reducer.fit_transform(X_scaled)
            explained_var = reducer.explained_variance_ratio_
            xlabel = f'PC1 ({explained_var[0]:.1%})'
            ylabel = f'PC2 ({explained_var[1]:.1%})'
        elif method == 'tsne':
            reducer = TSNE(
                n_components=2,
                random_state=42,
                perplexity=min(30, len(X_scaled) - 1)
            )
            X_reduced = reducer.fit_transform(X_scaled)
            xlabel, ylabel = 't-SNE 1', 't-SNE 2'
        else:
            raise ValueError(f"Unsupported dimensionality reduction methods: {method}")

        fig, axes = plt.subplots(2, 2, figsize=figsize)

        # 1. Cluster scatter plot
        scatter = axes[0, 0].scatter(
            X_reduced[:, 0],
            X_reduced[:, 1],
            c=labels,
            cmap='viridis',
            alpha=0.7,
            s=50,
            edgecolor='k'
        )
        axes[0, 0].set_xlabel(xlabel)
        axes[0, 0].set_ylabel(ylabel)
        axes[0, 0].set_title(f'Allelic pair clustering ({self.clustering_results["method"]})')
        plt.colorbar(scatter, ax=axes[0, 0])

        # 2. Cluster size bar chart
        unique_labels, counts = unique(labels, return_counts=True)
        colors = plt.cm.viridis(linspace(0, 1, len(unique_labels)))
        axes[0, 1].bar(
            range(len(unique_labels)),
            counts,
            color=colors,
            edgecolor='black'
        )
        axes[0, 1].set_xticks(range(len(unique_labels)))
        axes[0, 1].set_xticklabels([f'Cluster {l}' for l in unique_labels])
        axes[0, 1].set_ylabel('The number of allele pairs')
        axes[0, 1].set_title('Cluster size distribution')

        # 3. Feature heat map (sorted by clustering
        sorted_indices = argsort(labels)
        heatmap_data = X_scaled[sorted_indices].T

        im = axes[1, 0].imshow(heatmap_data, aspect='auto', cmap='RdBu_r', interpolation='nearest')
        axes[1, 0].set_xlabel('Allele pairs(Sort by cluster)')
        axes[1, 0].set_ylabel('Feature')
        axes[1, 0].set_yticks(range(len(features_used)))
        axes[1, 0].set_yticklabels(features_used, fontsize=8)
        axes[1, 0].set_title('Clustering feature pattern')
        plt.colorbar(im, ax=axes[1, 0])

        # 4. Cluster feature mean radar chart
        axes[1, 1].axis('off')
        radar_ax = fig.add_subplot(2, 2, 4, polar=True)

        n_features = len(features_used)
        angles = linspace(0, 2 * pi, n_features, endpoint=False).tolist()
        angles += angles[:1]

        for cluster_id in unique_labels:
            if cluster_id != -1:  # Ignore the noise points
                cluster_mask = labels == cluster_id
                cluster_means = X_scaled[cluster_mask].mean(axis=0)
                values = cluster_means.tolist()
                values += values[:1]

                radar_ax.plot(angles, values, linewidth=2,
                              label=f'Cluster {cluster_id}')
                radar_ax.fill(angles, values, alpha=0.1)

        radar_ax.set_xticks(angles[:-1])
        radar_ax.set_xticklabels(features_used, fontsize=8)
        radar_ax.set_title('Comparison of mean values of clustering features')
        radar_ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0))

        plt.tight_layout()
        plt.savefig(out_file, bbox_inches='tight')

    def identify_differential_patterns(
        self,
        cluster_id1: int,
        cluster_id2: int,
        alpha: float = 0.05
    ) -> None:
        """
        Identify the difference patterns between two clusters.

        Parameters:
        -----------
        cluster_id1, cluster_id2: The two cluster ids to be compared
        alpha: Significance level
        """
        if self.clustering_results is None:
            raise ValueError('Please run "clustering()" method first.')

        cluster_col = f"{self.clustering_results['method']}_cluster"

        cluster1_mask = self.pairwise_features[cluster_col] == cluster_id1
        cluster2_mask = self.pairwise_features[cluster_col] == cluster_id2

        features_used = self.clustering_results['features_used']
        diff_results = []

        for feature in features_used:
            data1 = self.pairwise_features.loc[cluster1_mask, feature].dropna()
            data2 = self.pairwise_features.loc[cluster2_mask, feature].dropna()

            if len(data1) > 1 and len(data2) > 1:
                # t test
                t_stat, t_pval = ttest_ind(data1, data2, equal_var=False)

                # Mann-Whitney U test (nonparametric)
                u_stat, u_pval = mannwhitneyu(data1, data2)

                # Calculate the effect size（Cohen's d）
                pooled_std = sqrt(((len(data1) - 1) * data1.std() ** 2 +
                                      (len(data2) - 1) * data2.std() ** 2) /
                                     (len(data1) + len(data2) - 2))
                cohens_d = (data1.mean() - data2.mean()) / pooled_std

                diff_results.append({
                    'feature': feature,
                    'cluster1_mean': data1.mean(),
                    'cluster2_mean': data2.mean(),
                    'mean_diff': data1.mean() - data2.mean(),
                    't_statistic': t_stat,
                    't_pvalue': t_pval,
                    't_significant': t_pval < alpha,
                    'u_statistic': u_stat,
                    'u_pvalue': u_pval,
                    'u_significant': u_pval < alpha,
                    'cohens_d': cohens_d,
                    'effect_size': 'small' if abs(cohens_d) < 0.5 else
                    'medium' if abs(cohens_d) < 0.8 else 'large'
                })

        self.differential_results[f'{cluster_id1}_vs_{cluster_id2}'] = DataFrame(diff_results)

    def get_cluster_alleles(self, cluster_id: int) -> List[str]:
        """
        Obtain all alleles in the specified cluster.

        Parameters:
        -----------
        cluster_id: Cluster ID

        Returns:
        --------
        List[str]: List of alleles
        """
        if self.clustering_results is None:
            raise ValueError('Please run "clustering()" method first.')

        cluster_col = f"{self.clustering_results['method']}_cluster"
        cluster_mask = self.pairwise_features[cluster_col] == cluster_id

        alleles = []
        for idx in self.pairwise_features[cluster_mask].index:
            row = self.pairwise_features.loc[idx]
            alleles.extend([row['allele1'], row['allele2']])

        l = list(set(alleles))
        l.sort(key=natsort_key)
        return l

    def save_clustering_results(self, output_prefix: str):
        """
        Save the clustering analysis results to file.

        Parameters:
        -----------
        output_prefix: Output prefix
        """
        if self.pairwise_features is not None:
            self.pairwise_features.to_csv(
                f'{output_prefix}_pairwise_features.xls',
                sep='\t'
            )

        if self.clustering_results is not None:
            with open(f'{output_prefix}_clustering_report.txt', 'w') as f:
                f.write(f"Clustering method: {self.clustering_results['method']}\n")
                f.write(f"Discover the number of clusters: {self.clustering_results['n_clusters']}\n")
                f.write(f"Features are used: {', '.join(self.clustering_results['features_used'])}\n")

                if self.clustering_results['quality_metrics']:
                    f.write("\nClustering quality index:\n")
                    for metric, value in self.clustering_results['quality_metrics'].items():
                        f.write(f"  {metric}: {value:.4f}\n")

        if self.differential_results:
            dfs_to_excel(
                df_list=list(self.differential_results.values()),
                sheets_name=list(self.differential_results.keys()),
                headers=None,
                indexes=None,
                output_file=f'{output_prefix}_differential_patterns.xlsx'
            )

# Allele-specific expression (ASE) analysis=============================================================================
    @staticmethod
    def _wilcoxon(loci_id: str, allele1_id: str, allele2_id: str, allele1_exp_array, allele2_exp_array) -> list:
        ret = [loci_id, allele1_id, allele2_id]
        try:
            w_stat, p_value = wilcoxon(allele1_exp_array, allele2_exp_array)
        except ValueError:
            w_stat = p_value = nan
        ret.extend([w_stat, p_value])
        ret.extend(list(allele1_exp_array))
        ret.extend(list(allele2_exp_array))
        return ret

    def wilcoxon(self, min_exp: float = 0.1, out_file: Union[str, TextIOWrapper, LazyFile] = None):
        allele_exp = filter_by_min_value(
            df=self.allele_exp,
            min_value=min_exp,
            start_column_num=1,
            end_column_num=None
        )

        allele_id_list = allele_exp.index.tolist()
        allele_pairs = defaultdict(list)
        params = []
        for loci_id, alleles in self.allele_pairs.items():
            if alleles[0] in allele_id_list and alleles[1] in allele_id_list:
                allele_pairs[loci_id] = alleles
                param = loci_id, alleles[0], alleles[1], allele_exp.loc[alleles[0]], allele_exp.loc[alleles[1]]
                params.append(param)

        data = []
        tkm = TaskManager(params=params, num_processing=self.num_processing)
        with tqdm(total=len(allele_pairs)) as pbar:
            rets = tkm.parallel_run_func(func=self._wilcoxon, call_back_func=lambda _: pbar.update())
        for ret in rets:
            data.append(ret.get())
        samples = allele_exp.columns.tolist()
        allele1_exp = [f'allele1_{sample}' for sample in samples]
        allele2_exp = [f'allele2_{sample}' for sample in samples]
        columns = ['locus_id', 'allele1', 'allele2', 't_statistics', 'p_value'] + allele1_exp + allele2_exp
        df = DataFrame(data=data, columns=columns)

        p_values = df['p_value'].fillna(1.0).values
        rejected, q_values, _, _ = multipletests(
            pvals=p_values,
            alpha=0.05,
            method='fdr_bh'
        )
        q_values = where(df['p_value'].isna(), nan, q_values)
        df.insert(loc=5, column='q_value', value=q_values)
        df.to_csv(out_file, sep='\t', na_rep='NA', index=False)

    @staticmethod
    def _ttest_rel(loci_id: str, allele1_exp_array, allele2_exp_array) -> list:
        allele1_id = allele1_exp_array.name
        allele2_id = allele2_exp_array.name
        ret = [loci_id, allele1_id, allele2_id]
        t_stat, p_value = ttest_rel(allele1_exp_array, allele2_exp_array)
        ret.extend([t_stat, p_value])
        ret.extend(list(allele1_exp_array))
        ret.extend(list(allele2_exp_array))
        return ret

    def ttest_rel(self, min_exp: float = 0.1, out_file: Union[str, TextIOWrapper, LazyFile] = None):
        allele_exp = filter_by_min_value(
            df=self.allele_exp,
            min_value=min_exp,
            start_column_num=1,
            end_column_num=None
        )

        allele_id_list = allele_exp.index.tolist()
        allele_pairs = defaultdict(list)
        params = []
        for loci_id, alleles in self.allele_pairs.items():
            if alleles[0] in allele_id_list and alleles[1] in allele_id_list:
                allele_pairs[loci_id] = alleles
                param = loci_id, allele_exp.loc[alleles[0]], allele_exp.loc[alleles[1]]
                params.append(param)

        data = []
        tkm = TaskManager(params=params, num_processing=self.num_processing)
        with tqdm(total=len(allele_pairs)) as pbar:
            rets = tkm.parallel_run_func(func=self._ttest_rel, call_back_func=lambda _: pbar.update())
        for ret in rets:
            data.append(ret.get())
        samples = allele_exp.columns.tolist()
        allele1_exp = [f'allele1_{sample}' for sample in samples]
        allele2_exp = [f'allele2_{sample}' for sample in samples]
        columns = ['locus_id', 'allele1', 'allele2', 't_statistics', 'p_value'] + allele1_exp + allele2_exp
        df = DataFrame(data=data, columns=columns)

        p_values = df['p_value'].fillna(1.0).values
        rejected, q_values, _, _ = multipletests(
            pvals=p_values,
            alpha=0.05,
            method='fdr_bh'
        )
        q_values = where(df['p_value'].isna(), nan, q_values)
        df.insert(loc=5, column='q_value', value=q_values)
        df.to_csv(out_file, sep='\t', na_rep='NA', index=False)


class RNASeqAnalysisWithReference(NGSAnalyser):
    def __init__(
        self,
        read1: str,
        read2: str,
        ref_genome: str,
        output_path: str,
        ref_gff: str = None,
        num_threads: int = 10,
        sample_name: str = None,
        exe_path_dict: Dict[str, str] = None
    ):
        self._exe_set.update({'stringtie'})
        super().__init__(read1, read2, ref_genome, output_path, num_threads, sample_name, exe_path_dict)
        self.ref_gff = abspath(ref_gff) if ref_gff is not None else ref_gff
        self.assembly_path = f'{self.output_path}/03.assembly/{self.sample_name}'
        self.stringtie_gtf = f'{self.assembly_path}/{self.sample_name}.st.gtf'

    def run_stringtie(
            self,
            sorted_bam: str = None,
            out_gtf: str = None,
            **other_options
    ):
        stringtie = which(self.exe_path_dict['stringtie'])
        sorted_bam = abspath(sorted_bam) if sorted_bam else self.hisat2_raw_bam
        out_gtf = abspath(out_gtf) if out_gtf else self.stringtie_gtf
        makedirs(self.assembly_path, exist_ok=True)
        cmd = (
            f'{stringtie} '
            f'-p {self.num_threads} '
            f'-l {self.sample_name} '
            f'-o {out_gtf} '
            f'{sorted_bam}'
        )
        return self.other_options(cmd, other_options) if other_options else cmd

    def ssRNA_seq_pipeline(
        self,
        fastp_options: dict = None,
        hisat2_options: dict = None,
        stringtie_options: dict = None,
        library_type: Literal['FR', 'RF'] = 'RF'
    ):
        if fastp_options is None:
            fastp_options = {
                '-j': f'{self.qc_path}/{self.sample_name}.fastp.json',
                '-h': f'{self.qc_path}/{self.sample_name}.fastp.html'
            }
        if hisat2_options is None:
            hisat2_options = {'--rna-strandness': library_type}
        if stringtie_options is None:
            stringtie_options = {f'--{library_type.lower()}': '', '-G': self.ref_gff} if self.ref_gff else\
                {f'--{library_type.lower()}': ''}
        cmds = (
            f"{self.run_fastp(**fastp_options)}\n\n"
            f'{self.run_hisat2(**hisat2_options)}\n\n'
            f'{self.run_stringtie(**stringtie_options)}'
        )
        return cmds


class LncRNAPredictor:
    _exe_set = {'CNCI.py', 'CPC2.py', 'PLEK', 'pfam_scan.pl', 'seqkit'}

    def __init__(
        self,
        nucl_fasta_file: str,
        output_path: str,
        num_thread: int = 10,
        module: Literal['ve', 'pl'] = 'pl',
        pep_fasta_file: str = None,
        PfamDatabase: str = None,
        exe_path_dict: Dict[str, str] = None
    ):
        if exe_path_dict is None:
            exe_path_dict = {}
        self.nucl = abspath(nucl_fasta_file)
        self.pep = abspath(pep_fasta_file) if pep_fasta_file else None
        self.PfamDatabase = abspath(PfamDatabase) if PfamDatabase else None
        self.output_path = abspath(output_path)
        self.num_thread = num_thread
        self.module = module
        self.exe_path_dict = FuncDict(
            {
                k: which(v)
                for k, v in exe_path_dict.items()
                if k in self._exe_set and which(v) is not None
            }
        )
        # output
        self.CNCI_out = f'{self.output_path}/CNCI/CNCI.index'
        self.CPC2_out = f'{self.output_path}/CPC2/CPC2.txt'
        self.PLEK_out = f'{self.output_path}/PLEK/PLEK.xls'
        self.PfamScan_out = f'{self.output_path}/PfamScan/pfamscan_out.txt'

    def run_CNCI(self):
        CNCI = which(self.exe_path_dict['CNCI.py'])
        cmd = f'{CNCI} -p {self.num_thread} -m {self.module} -f {self.nucl} -o {self.output_path}/CNCI'
        return cmd

    def run_CPC2(self):
        CPC2 = which(self.exe_path_dict['CPC2.py'])
        makedirs(f'{self.output_path}/CPC2', exist_ok=True)
        cmd = f'{CPC2} -i {self.nucl} --ORF TRUE -o {self.output_path}/CPC2/CPC2'
        return cmd

    def run_PLEK(self):
        PLEK = which(self.exe_path_dict['PLEK'])
        makedirs(f'{self.output_path}/PLEK', exist_ok=True)
        cmd = f'{PLEK} -thread {self.num_thread} -fasta {self.nucl} -out {self.PLEK_out}'
        return cmd

    def run_PfamScan(self):
        PfamScan = which(self.exe_path_dict['pfam_scan.pl'])
        makedirs(f'{self.output_path}/PfamScan', exist_ok=True)
        cmd = (
            f'{PfamScan} '
            f'-fasta {self.pep} '
            f'-dir {self.PfamDatabase} '
            f'-outfile {self.PfamScan_out}'
        )
        return cmd

    def merge_results(
        self,
        CNCI_results: str = None,
        CPC2_results: str = None,
        PLEK_results: str = None,
        PfamScan_results: str = None
    ):
        CNCI_results = abspath(CNCI_results) if CNCI_results else self.CNCI_out
        CPC2_results = abspath(CPC2_results) if CPC2_results else self.CPC2_out
        PLEK_results = abspath(PLEK_results) if PLEK_results else self.PLEK_out
        PfamScan_results = abspath(PfamScan_results) if PfamScan_results else self.PfamScan_out

        seqkit = which(self.exe_path_dict['seqkit'])
        CNCI_results = r'''awk '{if($0 ~/noncoding/){print $1}}' %s ''' % CNCI_results
        CPC2_results = r'''awk -F'\t' '{if($9 == "noncoding"){print $1}}' %s''' % CPC2_results
        PLEK_results = r'''awk '{if($1 ~ /Non-coding/){print $3}}' %s | sed 's/>//' ''' % PLEK_results
        awk1 = r'''awk -F' ' '{if($1 == 3){print $2}}' '''
        awk2 = r'''awk -F' ' '{print $1}' %s''' % PfamScan_results
        seqkit_cmd1 = f'{seqkit} grep -inrf - {self.nucl}'
        seqkit_cmd2 = f'{seqkit} seq -m 200 -'
        cmd = (
            f'cat <({CNCI_results}) <({CPC2_results}) <({PLEK_results}) | sort | uniq -c | {awk1} | '
            f'grep -vFwf <({awk2}) - | {seqkit_cmd1} | {seqkit_cmd2} > {self.output_path}/lncRNA.fa'
        )
        return cmd


class LncRNATargetPredictor:
    def __init__(
        self,
        lncRNA_gtf_file: Union[str, TextIOWrapper] = None,
        mRNA_gtf_file: Union[str, TextIOWrapper] = None,
        distance: int = 100000,
        lncRNA_exp_file: Union[str, TextIOWrapper] = None,
        mRNA_exp_file: Union[str, TextIOWrapper] = None,
        lncRNA_min_exp: float = 0.5,
        mRNA_min_exp: float = 0.5,
        r: float = 0.85,
        FDR: float = 0.05,
        q_value: float = 0.05,
        num_processing: int = 1,
        output_path: str = '.'
    ):
        self.lncRNA_gtf = abspath(lncRNA_gtf_file) if lncRNA_gtf_file is not None else None
        self.lncRNA_exp = abspath(lncRNA_exp_file) if lncRNA_exp_file is not None else None
        self.lncRNA_min_exp = lncRNA_min_exp
        self.mRNA_gtf = abspath(mRNA_gtf_file) if mRNA_gtf_file is not None else None
        self.mRNA_exp = abspath(mRNA_exp_file) if mRNA_exp_file is not None else None
        self.mRNA_min_exp = mRNA_min_exp
        self.distance = distance
        self.r, self.FDR, self.q_value = r, FDR, q_value
        self.num_processing = num_processing
        self.output_path = abspath(output_path)

    @staticmethod
    def intersect(row: Series, mRNA: DataFrame, distance: int):
        lncRNA_chr = row['Chromosome']
        lncRNA_start, lncRNA_end = row['Start'], row['End']
        start = lncRNA_start - distance if lncRNA_start - distance > 0 else 1
        end = lncRNA_end + distance
        lncRNA_strand = row['Strand']
        candidate_mRNA = mRNA[
            (mRNA['Chromosome'] == lncRNA_chr) &
            (start <= mRNA['Start']) &
            (end >= mRNA['End'])
            ]
        candidate_mRNA['LncRNA_id'] = row.name
        candidate_mRNA['LncRNA_start'] = lncRNA_start
        candidate_mRNA['LncRNA_end'] = lncRNA_end
        candidate_mRNA['LncRNA_strand'] = lncRNA_strand
        return candidate_mRNA

    def co_location(self):
        with Gtf(self.lncRNA_gtf) as lncRNA_gtf, Gtf(self.mRNA_gtf) as mRNA_gtf:
            lncRNA_df = lncRNA_gtf.merge_by_transcript()
            lncRNA_df.to_csv(f'{self.output_path}/lncRNA.bed', sep='\t')
            mRNA_df = mRNA_gtf.merge_by_transcript()
            mRNA_df.to_csv(f'{self.output_path}/mRNA.bed', sep='\t')
            params = ((row[1], mRNA_df, self.distance) for row in lncRNA_df.iterrows())
            tkm = TaskManager(num_processing=self.num_processing, params=params)
            with tqdm(total=len(lncRNA_df), desc='Co-location predicting') as pbar:
                rets = tkm.parallel_run_func(func=self.intersect, call_back_func=lambda _: pbar.update())
            dfs = [ret.get() for ret in rets]
            lncRNA_mRNA_df = concat(dfs)
            lncRNA_mRNA_df.to_csv(f'{self.output_path}/co_loc.xls', sep='\t')

    @staticmethod
    def sub_process(x_name, x_data, y_name, y_data):
        r, p = pearsonr(x_data, y_data)
        return [x_name, y_name, r, p]

    def co_expression(self):
        lncRNA_exp_dict = {}
        with open(self.lncRNA_exp) as lncRNA_exp_file:
            _ = lncRNA_exp_file.readline()  # skip header line
            for line in lncRNA_exp_file:
                if line.strip():
                    split = line.strip('\n').split('\t')
                    lncRNA_id = split[0]
                    lncRNA_exp = [float(i) for i in split[1:]]
                    if all([i >= self.lncRNA_min_exp for i in lncRNA_exp]):
                        lncRNA_exp_dict[lncRNA_id] = lncRNA_exp
        # lncRNA_exp_dict = {
        #     line.strip().split('\t')[0]: [float(i) for i in line.strip().split('\t')[1:]]
        #     for line in open(self.lncRNA_exp)
        #     if not line.startswith('Geneid') and line.strip() and
        #        all([float(i) >= self.lncRNA_min_exp for i in line.strip().split('\t')[1:]])
        # }

        mRNA_exp_dict = {}
        with open(self.mRNA_exp) as mRNA_exp_file:
            _ = mRNA_exp_file.readline()  # skip header line
            for line in mRNA_exp_file:
                if line.strip():
                    split = line.strip('\n').split('\t')
                    mRNA_id = split[0]
                    mRNA_exp = [float(i) for i in split[1:]]
                    if all([i >= self.mRNA_min_exp for i in mRNA_exp]):
                        mRNA_exp_dict[mRNA_id] = mRNA_exp
        # mRNA_exp_dict = {
        #     line.strip().split('\t')[0]: [float(i) for i in line.strip().split('\t')[1:]]
        #     for line in open(self.mRNA_exp)
        #     if not line.startswith('Geneid') and line.strip() and
        #        all([float(i) >= self.mRNA_min_exp for i in line.strip().split('\t')[1:]])
        # }

        with tqdm(total=len(lncRNA_exp_dict) * len(mRNA_exp_dict), desc='Co-expression predicting') as pbar:
            params = ((k1, v1, k2, v2) for k1, v1 in lncRNA_exp_dict.items() for k2, v2 in mRNA_exp_dict.items())
            tkm = TaskManager(num_processing=self.num_processing, params=params)
            rets = tkm.parallel_run_func(func=self.sub_process, call_back_func=lambda _: pbar.update())

        data = [ret.get() for ret in rets]
        raw = DataFrame(data=data, columns=['lncRNA_id', 'mRNA_id', 'pcc', 'p_value'])
        raw.sort_values(by=['lncRNA_id', 'p_value'], inplace=True, ascending=[True, True])
        raw.to_csv(f'{self.output_path}/raw_co_exp.xls', sep='\t', index=False, float_format='%.12f', na_rep='NA')

        filter_df = raw[(raw['pcc'].abs() >= self.r) & (raw['p_value'] <= self.q_value)]
        filter_df['q_value'] = multipletests(pvals=filter_df['p_value'], alpha=self.FDR, method='fdr_bh')[1]
        filter_df = filter_df[filter_df['q_value'] <= self.q_value]
        filter_df.sort_values(by=['lncRNA_id', 'q_value'], inplace=True, ascending=[True, True])
        filter_df.to_csv(f'{self.output_path}/filter_co_exp.xls', sep='\t', index=False, float_format='%.12f', na_rep='NA')


class LncRNAClassification:
    def __init__(
        self,
        mRNA_gff_file: str,
        lncRNA_gtf_file: str,
        out_dir: str
    ):
        self.mRNA_gff_file = abspath(mRNA_gff_file)
        self.mRNA_gtf_file = '.'.join(self.mRNA_gff_file.split('.')[:-1]) + '.gtf'
        self.lncRNA_gtf_file = abspath(lncRNA_gtf_file)
        out_dir = abspath(out_dir)
        makedirs(out_dir, exist_ok=True)
        self.gene_bed = f'{out_dir}/gene.bed'
        self.exon_bed = f'{out_dir}/exon.bed'
        self.intron_bed = f'{out_dir}/intron.bed'
        self.lncRNA_bed = f'{out_dir}/lncRNA.bed'
        self.sense = f'{out_dir}/sense.bed'
        self.antisense = f'{out_dir}/antisense.bed'
        self.intronic = f'{out_dir}/intronic.bed'
        self.intergenic = f'{out_dir}/intergenic.bed'

    def classification(self):
        bedtools = which('bedtools')
        gffread = which('gffread')

        gff2gtf = f'{gffread} {self.mRNA_gff_file} -T -o {self.mRNA_gtf_file}'

        gene_bed = (r'''awk -F'\t' '{if($3 == "gene"){print $1,$4,$5,$9,$6,$7}}' OFS='\t' %s | sort -uV > %s''' %
                    (self.mRNA_gff_file, self.gene_bed))
        exon_bed = (r'''awk -F'\t' '{if($3 == "exon"){print $1,$4,$5,$9,$6,$7}}' OFS='\t' %s | sort -uV > %s''' %
                    (self.mRNA_gtf_file, self.exon_bed))
        intron_bed = f'{bedtools} subtract -a {self.gene_bed} -b {self.exon_bed} -s | sort -uV > {self.intron_bed}'
        lncRNA_bed = (r'''awk -F'\t' '{print $1,$4,$5,$9,$6,$7}' OFS='\t' %s | sort -uV > %s''' %
                      (self.lncRNA_gtf_file, self.lncRNA_bed))

        intronic = f'{bedtools} intersect -a {self.lncRNA_bed} -b {self.intron_bed} -s > {self.intronic}'

        sense = (
                r'''%s intersect -a <(awk '{if(match($0, /transcript_id "[a-zA-Z0-9]*.[a-zA-Z0-9]*"/)) print substr($0, RSTART, RLENGTH)}' %s | sort -uV | grep -Fwvf - %s) -b %s -s > %s''' %
                (bedtools, self.intronic, self.lncRNA_bed, self.gene_bed, self.sense)
        )

        antisense = (
                r'''%s intersect -a <(cat %s %s | awk '{if(match($0, /transcript_id "[a-zA-Z0-9]*.[a-zA-Z0-9]*"/)) print substr($0, RSTART, RLENGTH)}' | sort -uV | grep -Fwvf - %s) -b %s -S > %s''' %
                (bedtools, self.intronic, self.sense, self.lncRNA_bed, self.gene_bed, self.antisense)
        )

        intergenic = (
                r'''%s subtract -a <(cat %s %s %s | awk '{if(match($0, /transcript_id "[a-zA-Z0-9]*.[a-zA-Z0-9]*"/)) print substr($0, RSTART, RLENGTH)}' | sort -uV | grep -Fwvf - %s) -b %s > %s''' %
                (bedtools, self.intronic, self.sense, self.antisense, self.lncRNA_bed, self.gene_bed, self.intergenic)
        )

        cmds = [gene_bed, exon_bed, intron_bed, lncRNA_bed, intronic, sense, antisense, intergenic]
        if not exists(self.mRNA_gtf_file):
            cmds.insert(0, gff2gtf)

        return '\n'.join(cmds)
