"""
File: genotype.py
Description: Instantiate a GT file object.
CreateDate: 2023/10/26
Author: xuwenlin
E-mail: wenlinxu.njfu@outlook.com
"""
from typing import Union, List, Tuple, Optional
from typing_extensions import Literal, Annotated
from functools import partial
from io import TextIOWrapper
from os import getcwd, makedirs
from os.path import abspath
from warnings import filterwarnings
from collections import defaultdict
import random
from re import sub
from tqdm import tqdm
from natsort import natsort_key
from numpy import nan, linspace, arange
from numpy.ma import masked_where
from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm
from pandas import Series, DataFrame, read_table, read_csv, read_excel, concat, to_numeric, isna
from matplotlib import pyplot as plt
from matplotlib.colors import ListedColormap, hsv_to_rgb
import matplotlib.patches as mpatches
from seaborn import heatmap, clustermap
from click import echo
from pybioinformatic.task_manager import TaskManager
from pybioinformatic.biopandas import read_file_as_df_from_stdin, interval_stat
from pybioinformatic.biomatplotlib import set_custom_font

filterwarnings("ignore")
set_custom_font('Arial')
plt.rcParams['pdf.fonttype'] = 42

# =====================================================================================================================#
# NOTICE:                                                                                                              #
# The "__check_hom" and "__get_all_allele" functions cannot be defined in the "GenoType" class.                        #
# Because the "GenoType.parallel_stat_MHM" method runs with multiprocessing,                                           #
# the subprocess cannot call the private method of the "GenoType" class.                                               #
# =====================================================================================================================#
def __check_hom(row: Series) -> Series:
    """Check which samples are homozygous genotypes at specific loci."""
    genotype_set = {'AT', 'TA',
                    'AG', 'GA',
                    'AC', 'CA',
                    'GC', 'CG',
                    'GT', 'TG',
                    'CT', 'TC'}
    data = [str(value) not in genotype_set and '/' not in str(value) and str(value) != ''
            for value in row]
    return Series(data, row.index)


def __get_all_allele(row: Series) -> str:
    """Get all allele at specified loci."""
    all_allele = ''
    ref = row[0]
    for value in row[1:]:
        if '/' in str(value):
            left, right = str(value).split('/')[0], str(value).split('/')[1]
            if 'ins' in left:
                all_allele += 'I'
            elif 'del' in left:
                all_allele += 'D'
            elif left == '-':
                all_allele += ref[0]
            else:
                all_allele += left[0]
            if 'ins' in right:
                all_allele += 'I'
            elif 'del' in right:
                all_allele += 'D'
            elif right == '-':
                all_allele += ref[0]
            else:
                all_allele += right[0]
        elif 'ins' in str(value):
            all_allele += 'II'
        elif 'del' in str(value):
            all_allele += 'DD'
        elif str(value) == '-':
            all_allele += ref[0] * 2
        else:
            value = str(value).replace('*', 'U')
            all_allele += value
    return all_allele


def __allele_sort(allele: str) -> str:
    if '/' in allele:
        return '/'.join(sorted(allele.split('/')))
    elif 'ins' in allele or 'del' in allele:
        return allele
    else:
        return ''.join(sorted(allele))


def allele_sort(df: DataFrame) -> DataFrame:
    snp_ref = df.iloc[:, :4]
    sorted_allele = df.iloc[:, 4:].applymap(__allele_sort, na_action='ignore')
    df = snp_ref.join(sorted_allele)
    return df


def filter_mendelian_errors(df: DataFrame, parents: List[str], offsprings: List[str] = None) -> Tuple[DataFrame, DataFrame]:
    def get_offspring_probable_gt(row: Series) -> Series:
        if len(row) == 6:  # 提供了2个亲本
            row['probable_gt1'] = row.iloc[4][0] + row.iloc[5][0]
            row['probable_gt2'] = row.iloc[4][0] + row.iloc[5][1]
            row['probable_gt3'] = row.iloc[4][1] + row.iloc[5][0]
            row['probable_gt4'] = row.iloc[4][1] + row.iloc[5][1]
        else:  # 仅提供了1个亲本
            row['probable_gt1'] = row.iloc[4][0]
            row['probable_gt2'] = row.iloc[4][1]
        return row

    def filter_snp(row: Series) -> Series:
        num_correct_gt = len([i for i in row.index if 'probable_gt' in i])
        if num_correct_gt == 4:
            correct_gt = list(row[-num_correct_gt:])
            if all([gt in correct_gt for gt in row[4:-num_correct_gt]]):
                return row[:-num_correct_gt]
            else:
                return Series()
        elif num_correct_gt == 2:
            correct_gt = set(row[-num_correct_gt:])
            if all([set(gt) & correct_gt for gt in row[4:-num_correct_gt]]):
                return row[:-num_correct_gt]
            else:
                return Series()
        else:
            return Series()

    # 等位基因排序
    df = allele_sort(df)
    # 拆解亲本和子代基因型并过滤孟德尔错误
    loci_info = df.columns.tolist()[:4]
    samples = df.columns.tolist()[4:]
    if offsprings is None:  # 如果不提供子代样本名
        offsprings = list(set(samples) - set(parents))  # 默认将除了亲本以外的样本都视为子代
    offsprings.sort(key=natsort_key)
    if 0 < len(parents) <= 2:
        parents_gt = allele_sort(df.loc[:, loci_info + parents].apply(get_offspring_probable_gt, axis=1))
        num_probable_gt = len(parents) * 2
        offspring_gt = concat(
            objs=[
                df.loc[:, loci_info + offsprings],
                parents_gt.iloc[:, -num_probable_gt:]
            ],
            axis=1
        ).apply(filter_snp, axis=1).dropna()
    else:
        echo(f"\033[31mError: Invalid number of parents: {len(parents)}.\033[0m", err=True)
        exit()

    pass_df = df.loc[offspring_gt.index].reset_index(drop=True)  # 符合孟德尔遗传的位点
    filtered_df = df.loc[~df.index.isin(offspring_gt.index)].reset_index(drop=True)  # 不符合孟德尔遗传的位点

    return pass_df, filtered_df


def stat_MHM(df: DataFrame) -> DataFrame:
    """
    Calculate MissRate, HetRate, and MAF (MHM) from specified DataFrame.
    The top 4 columns of DataFrame must be SNP ID, chromosome, position, and reference sequence info respectively,
    and the header of DataFrame is not None.
    """
    snp_ref = df.iloc[:, :4]
    # Calculate MissRate
    sample_num = len(df.columns.tolist()) - 4
    df['MissRate(%)'] = df.isnull().sum(axis=1) / sample_num * 100
    # Calculate HetRate
    df.fillna('', inplace=True)  # fill NA
    df['HetRate(%)'] = df.iloc[:, 4:-1].apply(lambda row: (1 - __check_hom(row).sum() / (row != '').sum()) * 100, axis=1)
    # Calculate MAF
    df['all_gt'] = df.iloc[:, 3:-2].apply(lambda row: __get_all_allele(row), axis=1)
    df['total'] = df['all_gt'].apply(len)
    df['A'] = df['all_gt'].str.count('A') / df['total']
    df['G'] = df['all_gt'].str.count('G') / df['total']
    df['C'] = df['all_gt'].str.count('C') / df['total']
    df['T'] = df['all_gt'].str.count('T') / df['total']
    df['D'] = df['all_gt'].str.count('D') / df['total']
    df['I'] = df['all_gt'].str.count('I') / df['total']
    df['U'] = df['all_gt'].str.count('U') / df['total']
    df['MAF'] = df.loc[:, ['A', 'G', 'C', 'T', 'D', 'I', 'U']].apply(lambda row: sorted(row, reverse=True)[1], axis=1)
    # Output results
    df = df.loc[:, ['MissRate(%)', 'HetRate(%)', 'MAF']]
    merge = snp_ref.join(df)
    return merge


class GenoType:
    """
    Standard genotype file object.
    """

    def __init__(self, path: Union[str, TextIOWrapper]):
        self.name = abspath(path) if isinstance(path, str) else abspath(path.name)
        self.__open = open(path) if isinstance(path, str) else path

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            self.__open.close()
        except AttributeError:
            pass

    def to_dataframe(
        self,
        sheet: Union[str, int, List[Union[str, int]]] = 0,
        index_col: Union[int, str, None] = None,
        sort_allele: bool = True
    ) -> DataFrame:
        # parse genotype file as dataframe
        try:  # read from text file
            if 'gz' in self.name:
                df = read_csv(self.name, sep='\t', index_col=None)
            else:
                df = read_csv(self.__open, sep='\t', index_col=None)
        except UnicodeDecodeError:  # read from Excel file
            df = read_excel(self.name, sheet, index_col=None)

        # sort allele
        if sort_allele:
            df = allele_sort(df)

        # set index
        if index_col is not None:
            if isinstance(index_col, int):
                index_col = df.columns.tolist()[index_col]
            df.set_index(keys=index_col, inplace=True)
            df.sort_index(key=natsort_key, inplace=True)  # sort by index
        else:
            df.sort_values([df.columns[1], df.columns[2]], key=natsort_key, inplace=True)  # sort by position

        self.__open.seek(0)

        return df

    def to_dataframes(
        self,
        sheet: Union[str, int, List[Union[str, int]]] = 0,
        index_col: Union[int, str, None] = None,
        chunk_size: int = 10000
    ) -> DataFrame:
        if 'stdin' in self.name:  # read from stdin
            dfs = read_file_as_df_from_stdin(chunk_size=chunk_size, index_col=index_col)
        elif self.name.endswith('gz'):  # read from compressed text (xx.gz) file
            dfs = read_table(self.name, chunksize=chunk_size, index_col=index_col)
        else:
            try:  # read from text file
                dfs = read_table(self.__open, chunksize=chunk_size, index_col=index_col)
            except UnicodeDecodeError:  # read from Excel file
                echo('\033[33mWarning: Excel file cannot be processed in chunks.\033[0m', err=True)
                return self.to_dataframe(sheet, index_col)
        self.__open.seek(0)
        return dfs

    def filter_mendelian_errors(
        self,
        parents: List[str],
        offsprings: List[str] = None,
        num_processing: int = 1
    ) -> Tuple[DataFrame, DataFrame]:
        dfs = self.to_dataframes(index_col=None, chunk_size=10000)
        params = ((df, parents, offsprings) for df in dfs)  # index of DataFrame is 0, 1, 2, ...
        tkm = TaskManager(num_processing=num_processing, params=params)
        rets = tkm.parallel_run_func(filter_mendelian_errors)
        t = [i.get() for i in rets]  # [(pass_df, filtered_df), (), ...]

        pass_dfs = [i[0] for i in t]
        pass_df = concat(pass_dfs)
        pass_df.sort_values(pass_df.columns.tolist()[1:3], inplace=True, key=natsort_key)
        pass_df.reset_index(drop=True, inplace=True)

        filtered_dfs = [i[1] for i in t]
        filtered_df = concat(filtered_dfs)
        filtered_df.sort_values(filtered_df.columns.tolist()[1:3], inplace=True, key=natsort_key)
        filtered_df.reset_index(drop=True, inplace=True)

        return pass_df, filtered_df

    def filter_allele(self, min_alleles: int, max_alleles: int) -> DataFrame:
        df = self.to_dataframe(index_col=0)
        sub_df = df.iloc[:, 3:]
        combined = (
            sub_df
            .fillna('')  # 将NaN替换为空字符串
            .stack()  # 展开为多级索引Series
            .groupby(level=0)  # 按原始行索引分组
            .agg(''.join)  # 连接所有字符串
        )
        result = (
            combined
            .apply(lambda s: ''.join(sorted(set(s))))  # 去重并排序
            .rename('combined')  # 重命名结果列
        )
        df = concat([df, result], axis=1)
        columns = df.columns.tolist()[:-1]
        filtered_df = df.loc[(df.combined.str.len() <= max_alleles) & (df.combined.str.len() >= min_alleles), columns]
        filtered_df.sort_index(inplace=True)
        filtered_df.replace('', 'NA', inplace=True)
        return filtered_df

    def parallel_stat_MHM(self, num_processing: int = 1) -> DataFrame:
        """Calculate the MissRate, HetRate and MAF (MHM) of SNP from GT files parallely."""
        dfs = self.to_dataframes()
        params = ((df,) for df in dfs)  # Index of DataFrame is 0, 1, 2, ...
        tkm = TaskManager(num_processing=num_processing, params=params)
        ret = tkm.parallel_run_func(stat_MHM)
        stat_dfs = [i.get() for i in ret]
        # Merge results of each multiprocessing
        stat_df = concat(stat_dfs)
        stat_df.sort_values(stat_df.columns.tolist()[1:3], inplace=True, key=natsort_key)
        stat_df.fillna(0, inplace=True)
        return stat_df

    def merge(
        self, other,
        how: Literal['inner', 'outer'],
        sheet1: Union[str, int, List[Union[str, int]]] = None,
        sheet2: Union[str, int, List[Union[str, int]]] = None
    ) -> DataFrame:
        df1 = self.to_dataframe(sheet=sheet1, index_col=None, sort_allele=True)
        df1[df1.columns[1]] = df1[df1.columns[1]].astype(str)
        df1[df1.columns[2]] = df1[df1.columns[2]].astype(str)
        df1['tmp'] = df1[df1.columns[1]] + '_' + df1[df1.columns[2]] + '_' + df1[df1.columns[3]]
        df1.set_index('tmp', drop=True, inplace=True)
        df1 = df1.iloc[:, 4:]

        df2 = other.to_dataframe(sheet=sheet2, index_col=None, sort_allele=True)
        df2[df2.columns[1]] = df2[df2.columns[1]].astype(str)
        df2[df2.columns[2]] = df2[df2.columns[2]].astype(str)
        df2['tmp'] = df2[df2.columns[1]] + '_' + df2[df2.columns[2]] + '_' + df2[df2.columns[3]]
        df2.set_index('tmp', drop=True, inplace=True)
        df2 = df2.iloc[:, 4:]

        merge = df1.join(other=df2, how=how)
        samples = merge.columns.tolist()
        samples.sort(key=natsort_key)
        merge = merge.loc[:, samples]
        merge.insert(0, 'Chr', [i.split('_')[0] for i in merge.index.tolist()])
        merge.insert(1, 'Pos', [i.split('_')[1] for i in merge.index.tolist()])
        merge.insert(2, 'Ref', [i.split('_')[2] for i in merge.index.tolist()])
        merge.index.name = 'ID'
        merge.rename(index=lambda i: '_'.join(i.split('_')[:2]), inplace=True)
        merge.fillna('NA', inplace=True)
        merge.sort_index(key=natsort_key, inplace=True)
        return merge

    @staticmethod
    def __draw_gs_heatmap(
        consistency_df: DataFrame,
        cmap: str = "crest",
        output_path: str = getcwd()
    ) -> None:
        # Set font and dpi.
        dpi = 300
        if len(consistency_df) <= 40:
            font_size = 12
        elif 40 < len(consistency_df) <= 100:
            font_size = 8
        elif 100 < len(consistency_df) <= 150:
            font_size = 6
        else:
            font_size = 4
        plt.rcParams['font.size'] = font_size
        # Set figure attributions.
        plt.figure(figsize=(15, 10))
        # Plot heatmap.
        ax = heatmap(
            data=consistency_df,
            cmap=cmap,
            linecolor='w',
            linewidths=0.5,
            xticklabels=True,
            yticklabels=True,
            cbar_kws={'shrink': 0.4}
        )
        plt.tick_params('both', length=0)  # Set scale length.
        # Set color bar ticks and ticks label.
        min_gs = consistency_df.min(numeric_only=True).min() + 1
        max_gs = consistency_df.max(numeric_only=True).max()
        min_value = int(min_gs)
        max_value = int(max_gs)
        step = int((max_value - min_value) / 10)
        step = 1 if step == 0 else step
        cbar = ax.collections[0].colorbar
        cbar_ticks = [i for i in range(min_value, max_value + step, step) if i <= 100]
        cbar.set_ticks(cbar_ticks)
        cbar.set_ticklabels(cbar_ticks, fontsize=8)
        cbar.ax.tick_params(width=0.3)
        # # Save figure.
        plt.savefig(f'{output_path}/GS_heatmap.png', bbox_inches='tight', dpi=dpi)
        plt.savefig(f'{output_path}/GS_heatmap.pdf', bbox_inches='tight', dpi=dpi)

    @staticmethod
    def __draw_gs_cluster_heatmap(
        consistency_df: DataFrame,
        cmap: str = "vlag",
        output_path: str = getcwd()
    ) -> None:
        dpi = 300
        if len(consistency_df) <= 40:
            font_size = 12
        elif 40 < len(consistency_df) <= 100:
            font_size = 8
        elif 100 < len(consistency_df) <= 150:
            font_size = 6
        else:
            font_size = 4
        plt.rcParams['font.size'] = font_size

        for i in range(len(consistency_df.columns)):
            consistency_df.iloc[i, i] = 100
            for j in range(i + 1, len(consistency_df.columns)):
                consistency_df.iloc[i, j] = consistency_df.iloc[j, i]
        ax = clustermap(
            data=consistency_df,
            cmap=cmap,
            xticklabels=True,
            yticklabels=True,
            dendrogram_ratio=(0.1, 0.1),  # tree diagram percentage
            cbar_pos=(0.999, 0.6, 0.03, 0.3)  # cbar pos
        )
        ax.savefig(f'{output_path}/GS_cluster_heatmap.png', bbox_inches='tight', dpi=dpi)
        ax.savefig(f'{output_path}/GS_cluster_heatmap.pdf', bbox_inches='tight', dpi=dpi)

    def self_compare(
        self, other,
        sheet1: Union[str, int, List[Union[str, int]]] = None,
        sheet2: Union[str, int, List[Union[str, int]]] = None,
        output_path: str = getcwd()
    ) -> None:
        """Calculate genotype consistency of different sequencing batches in a single sample."""
        # Read in gt.
        df1 = self.to_dataframe(sheet1, index_col=0, sort_allele=False)
        df1[df1.columns[0]] = df1[df1.columns[0]].astype(str)
        df1[df1.columns[1]] = df1[df1.columns[1]].astype(str)
        df1['tmp'] = df1[df1.columns[0]] + '_' + df1[df1.columns[1]] + '_' + df1[df1.columns[2]]
        df1.set_index('tmp', drop=True, inplace=True)
        df2 = other.to_dataframe(sheet2, index_col=0, sort_allele=False)
        df2[df2.columns[0]] = df2[df2.columns[0]].astype(str)
        df2[df2.columns[1]] = df2[df2.columns[1]].astype(str)
        df2['tmp'] = df2[df2.columns[0]] + '_' + df2[df2.columns[1]] + '_' + df2[df2.columns[2]]
        df2.set_index('tmp', drop=True, inplace=True)
        # Check whether the two GT files contain the same loci.
        if df1.index.tolist() != df2.index.tolist():
            echo('\033[31mError: The two GT file loci to be compared are inconsistent.\033[0m', err=True)
            exit()
        # Calculate genotype consistency of each sample under different test batches.
        samples = set(df1.columns[3:]) & set(df2.columns[3:])
        data = []
        with tqdm(total=len(samples), unit='sample') as pbar:
            for sample in samples:
                NA_site = set(df1[sample][df1[sample].isnull()].index) | set(df2[sample][df2[sample].isnull()].index)
                NA_num = len(NA_site)
                series1 = df1[sample][~df1[sample].isnull()]
                series2 = df2[sample][~df2[sample].isnull()]
                IdenticalCount = series1.eq(series2).sum()
                TotalCount = len(df1) - NA_num
                GS = IdenticalCount / TotalCount * 100
                data.append([sample, IdenticalCount, NA_num, TotalCount, GS])
                pbar.update(1)
        bins = range(0, 105, 5)  # Set the consistency statistics interval.
        sample_consistency = DataFrame(data, columns=['SampleName', 'IdenticalCount', 'NaCount', 'TotalCount', 'GS(%)'])
        sample_consistency.sort_values('SampleName', key=natsort_key, inplace=True)
        sample_consistency.fillna(0.000, inplace=True)
        interval_stat_df = interval_stat(ser=sample_consistency['GS(%)'], bins=bins, precision=0, name='Count')
        # Write results to output file.
        sample_consistency.to_csv(f'{output_path}/Sample.consistency.xls', sep='\t', index=False)
        interval_stat_df.to_csv(f'{output_path}/Interval.stat.xls', sep='\t', header=False)

    def compare(
        self, other,
        sheet1: Union[str, int, List[Union[str, int]], None] = None,
        sheet2: Union[str, int, List[Union[str, int]], None] = None,
        cmap: str = "crest",
        output_path: str = getcwd()
    ) -> None:
        """Calculate genotype similarity between query and database samples."""
        makedirs(output_path, exist_ok=True)
        # Step1: Read GT file as DataFrame.
        df1 = self.to_dataframe(sheet=sheet1, index_col=None, sort_allele=True)  # index = 0, 1, 2, ...
        df2 = other.to_dataframe(sheet=sheet2, index_col=None, sort_allele=True)  # index = 0, 1, 2, ...
        # Step2: Select the site intersection of two GT files.
        left_on = df1.columns[0]
        right_on = df2.columns[0]
        merge = df1.merge(df2, left_on=left_on,  # index = 0, 1, 2, ...
                          right_on=right_on)  # Avoid inconsistency between the two GT file ID fields
        # Step3: Calculate genotype consistency.
        df1_sample_num = len(df1.columns.tolist()) - 4
        left_sample_range = list(range(4, 4 + df1_sample_num))
        if df1.columns[0] == df2.columns[0]:
            right_sample_range = list(range(len(df1.columns) + 3, len(merge.columns)))
        else:
            right_sample_range = list(range(len(df1.columns) + 4, len(merge.columns)))
        consistency_df = DataFrame()
        sample_pair = set()
        data = []
        with tqdm(total=len(left_sample_range), unit='sample') as pbar:  # Show process bar
            for index1 in left_sample_range:
                gt1 = merge.iloc[:, index1]
                gt1_NA = set(gt1[gt1.isnull()].index)
                gt1.name = sub(r'_x\b', '', gt1.name)
                pbar.set_description(f'Processing {gt1.name}')
                for index2 in right_sample_range:
                    gt2 = merge.iloc[:, index2]
                    gt2_NA = set(gt1[gt2.isnull()].index)
                    NA_site_index = gt1_NA | gt2_NA
                    NA_num = len(NA_site_index)
                    TotalCount = len(merge) - NA_num
                    gt2.name = sub(r'_y\b', '', gt2.name)
                    gt1 = gt1[~gt1.isnull()]
                    gt2 = gt2[~gt2.isnull()]
                    IdenticalCount = gt1.eq(gt2).sum()
                    GS = 0.00 if TotalCount == 0 else '%.2f' % (IdenticalCount / TotalCount * 100)
                    data.append([gt1.name, gt2.name, IdenticalCount, NA_num, TotalCount, GS])
                    if gt1.name != gt2.name:
                        if (f'{gt1.name}-{gt2.name}' not in sample_pair) and \
                                (f'{gt2.name}-{gt1.name}' not in sample_pair):
                            consistency_df.loc[gt2.name, gt1.name] = GS
                            sample_pair.add(f'{gt1.name}-{gt2.name}')
                            sample_pair.add(f'{gt2.name}-{gt1.name}')
                    else:
                        consistency_df.loc[gt1.name, gt2.name] = ''
                pbar.update(1)
        header = ['Sample1', 'Sample2', 'IdenticalCount', 'NaCount', 'TotalCount', 'GS(%)']
        fmt1 = DataFrame(data, columns=header)
        fmt1.sort_values(['Sample1', 'GS(%)', 'Sample2'], key=natsort_key, inplace=True, ascending=[True, False, True])
        fmt1.to_csv(f'{output_path}/Sample.consistency.fmt1.xls', sep='\t', index=False)
        # Step4: Draw consistency heatmap.
        consistency_df.to_csv(f'{output_path}/Sample.consistency.fmt2.xls', sep='\t', na_rep='')
        self.__draw_gs_heatmap(
            consistency_df=read_table(f'{output_path}/Sample.consistency.fmt2.xls', index_col=0),
            cmap=cmap,
            output_path=output_path
        )
        # Step5: Draw consistency cluster heatmap.
        self.__draw_gs_cluster_heatmap(
            consistency_df=read_table(f'{output_path}/Sample.consistency.fmt2.xls', index_col=0),
            cmap=cmap,
            output_path=output_path
        )
        # Step6: Output GT file of test sample.
        right_sample_range.insert(0, 0)  # Only output site ID
        right_sample_range.insert(1, len(df1.columns) + 2)
        test_sample_gt_df = merge.iloc[:, right_sample_range]
        test_sample_gt_df.rename(columns=lambda i: sub(r'_[xy]\b', '', str(i)), inplace=True)
        test_sample_gt_df.sort_values(merge.columns[0], key=natsort_key, inplace=True)
        test_sample_gt_df.to_csv(f'{output_path}/Compare.GT.xls', sep='\t', index=False, na_rep='NA')

    def find_min_distinguishing_snps(self) -> DataFrame:
        """
        Find the smallest set of SNP loci that can distinguish all samples by greedy forward choice.
        Each time, greedily pick one from the "remaining candidates" to join.
        """
        df = self.to_dataframe(index_col=0, sort_allele=True)
        non_sample_columns = ['Chrom', 'Position', 'Ref']
        sample_columns = [col for col in df.columns if col not in non_sample_columns]
        # 只保留样本列
        genotype_matrix = df[sample_columns].values

        # 初始化等价类（初始所有样本在同一类）
        equivalence_classes = [set(range(len(sample_columns)))]
        selected_snps = []

        # 当存在包含多个样本的等价类时继续
        while any(len(eq) > 1 for eq in equivalence_classes):
            best_snp = None
            best_gain = -1
            best_new_classes = None

            # 遍历所有SNP位点
            for snp_idx in range(len(df)):
                if snp_idx in selected_snps:
                    continue

                # 创建新的等价类划分
                new_classes = []

                # 对每个现有等价类进行细分
                for eq in equivalence_classes:
                    # 按当前SNP的基因型细分
                    subgroups = defaultdict(set)
                    for sample_idx in eq:
                        genotype = genotype_matrix[snp_idx, sample_idx]
                        subgroups[genotype].add(sample_idx)

                    # 添加非空子组
                    for subgroup in subgroups.values():
                        if subgroup:
                            new_classes.append(subgroup)

                # 计算信息增益（减少的未区分样本对数）
                current_undistinguished = sum(len(eq) * (len(eq) - 1) // 2 for eq in equivalence_classes)
                new_undistinguished = sum(len(eq) * (len(eq) - 1) // 2 for eq in new_classes)
                gain = current_undistinguished - new_undistinguished

                # 选择增益最大的SNP
                if gain > best_gain:
                    best_gain = gain
                    best_snp = snp_idx
                    best_new_classes = new_classes

            # 如果没有找到增益的SNP，停止
            if best_gain <= 0:
                break

            # 添加最佳SNP并更新等价类
            selected_snps.append(best_snp)
            equivalence_classes = best_new_classes

        min_snps = df.iloc[selected_snps][non_sample_columns + sample_columns]
        min_snps.sort_index(key=natsort_key, inplace=True)
        return min_snps

    def draw_genotype_heatmap(
        self,
        genotype_colors: Union[List[str], None] = None,
        figure_size: Union[Tuple[Union[int, float], Union[int, float]], Annotated[List[Union[int, float]], "Length=2"]] = (10, 8),
        font_size: Union[int, float] = 10,
        out_file: str = 'genotype_heatmap.pdf'
    ) -> None:
        plt.rcParams['font.size'] = font_size
        if genotype_colors is None:
            genotype_colors = ['#2c7bb6', '#ffffbf', '#d7191c']

        # 1. 读取基因型数据
        df = self.to_dataframe(index_col=0, sort_allele=True)

        # 2. 数据预处理
        # 提取样本列（排除元数据列）
        df.sort_index(key=natsort_key, inplace=True)
        sorted_samples = df.columns.tolist()[3:]
        sorted_samples.sort(key=natsort_key)
        df = df.loc[:, ['Chrom', 'Position', 'Ref'] + sorted_samples]
        sample_columns = [col for col in df.columns if col not in ['Chrom', 'Position', 'Ref']]
        # 创建基因型矩阵
        genotype_matrix = df[sample_columns]

        # 3. 基因型编码（将基因型转换为数值）
        def encode_genotype(gt, ref):
            """Encode the genotype as a numerical value"""
            if gt == ref + ref:  # 参考纯合子
                return 0
            elif ref in gt and len(set(gt)) == 2:  # 杂合子
                return 1
            elif ref not in gt:  # 变异纯合子
                return 2
            else:  # 缺失或未知
                return nan

        # 创建编码矩阵
        encoded_matrix = DataFrame(index=genotype_matrix.index, columns=genotype_matrix.columns)

        for idx in genotype_matrix.index:
            ref = df.loc[idx, 'Ref']  # 获取当前SNP的参考等位基因
            for col in genotype_matrix.columns:
                gt = genotype_matrix.loc[idx, col]
                encoded_matrix.loc[idx, col] = encode_genotype(gt, ref)

        encoded_matrix = encoded_matrix.astype(float)
        if len(sample_columns)  > len(df) and len(sample_columns) > 50:
            encoded_matrix = encoded_matrix.T  # 转置矩阵，使样本在Y轴

        # 4. 创建自定义颜色映射
        genotype_cmap = ListedColormap(genotype_colors)

        # 5. 使用Seaborn绘制静态热图并添加基因型文本
        plt.figure(figsize=figure_size)

        # 创建热图
        ax = heatmap(
            encoded_matrix,
            cmap=genotype_cmap,
            cbar_kws={
                'ticks': [-0.5, 0.5, 1.5],
                'boundaries': [-1, 0, 1, 2],
                'shrink': 0.2,  # 缩小比例 (0.0-1.0)
                'aspect': 15  # 颜色条宽高比 (宽度/高度)
            },
            linewidths=0.5,
            linecolor='lightgray',
            vmin=-0.5,
            vmax=2.5,
            annot=False,  # 不使用seaborn的注释，而是自定义
            fmt="",
            square=True
        )

        # 设置颜色条标签
        cbar = ax.collections[0].colorbar
        cbar.set_ticklabels(['Ref Homo', 'Hetero', 'Alt Homo'], fontsize=font_size - 2)
        # cbar.set_label('Genotype Category', fontsize=12)

        # 添加基因型文本
        if len(sample_columns)  > len(df) and len(sample_columns) > 50:
        # 注意：由于我们转置了矩阵，需要调整索引
            for i, sample in enumerate(encoded_matrix.index):  # i: 样本索引 (Y轴)
                for j, snp in enumerate(encoded_matrix.columns):  # j: SNP索引 (X轴)
                    # 获取原始基因型
                    gt = genotype_matrix.loc[snp, sample]  # 注意索引顺序

                    # 获取当前单元格的编码值
                    cell_val = encoded_matrix.iloc[i, j]

                    # 根据背景色选择文本颜色
                    # 黄色背景用黑色文本，其他用白色文本
                    text_color = 'black' if cell_val == 1 else 'white'

                    # 添加文本
                    plt.text(
                        j + 0.5,  # x位置（单元格中心）
                        i + 0.5,  # y位置（单元格中心）
                        gt,  # 基因型文本
                        ha='center',
                        va='center',
                        color=text_color,
                        fontsize=font_size - 2
                    )
        else:
            # 添加基因型文本（不转置版本）
            # i: SNP索引 (行/Y轴), j: 样本索引 (列/X轴)
            for i, snp in enumerate(encoded_matrix.index):  # 遍历每个SNP（行）
                for j, sample in enumerate(encoded_matrix.columns):  # 遍历每个样本（列）
                    # 获取原始基因型
                    gt = genotype_matrix.loc[snp, sample]

                    # 获取当前单元格的编码值
                    cell_val = encoded_matrix.iloc[i, j]

                    # 根据背景色选择文本颜色
                    # 黄色背景用黑色文本，其他用白色文本
                    text_color = 'black' if cell_val == 1 else 'white'

                    # 添加文本
                    plt.text(
                        j + 0.5,  # x位置（单元格中心，列位置）
                        i + 0.5,  # y位置（单元格中心，行位置）
                        gt,  # 基因型文本
                        ha='center',
                        va='center',
                        color=text_color,
                        fontsize=font_size - 2
                    )

        # 添加标题和标签
        if len(sample_columns)  > len(df) and len(sample_columns) > 50:
            plt.xlabel('SNP ID', labelpad=15, fontsize=font_size + 2)
            plt.ylabel('Samples', labelpad=15, fontsize=font_size + 2)
        else:
            plt.xlabel('Samples', labelpad=15, fontsize=font_size + 2)
            plt.ylabel('SNP ID', labelpad=15, fontsize=font_size + 2)

        # 旋转SNP标签以提高可读性
        plt.xticks(rotation=60)

        plt.tight_layout()  # 优化布局
        plt.savefig(out_file, dpi=300, bbox_inches='tight')

    def draw_finger_print(self, output_file: str = 'fingerprint.png'):
        # ---------- 1. 读取数据 ----------
        df = self.to_dataframe(index_col=None, sort_allele=True)

        # 确定元数据列和样本列
        meta_cols = ["ID", "Chrom", "Position", "Ref"]
        if all(col in df.columns for col in meta_cols):
            sample_cols = [c for c in df.columns if c not in meta_cols]
        else:
            sample_cols = df.columns[4:].tolist()

        # ---------- 2. 按染色体和位置排序 ----------
        df["Position"] = to_numeric(df["Position"], errors="coerce")
        if "Chrom" in df.columns:
            df.sort_values(["Chrom", "Position"], inplace=True)
        else:
            df.sort_values("Position", inplace=True)

        # ---------- 3. 提取基因型矩阵，识别缺失 ----------
        geno_df = df[sample_cols].astype(str)
        # 定义缺失模式：NaN、空字符串、'nan'（不区分大小写）
        is_missing = geno_df.isin(["", "nan", "NaN", "None"]) | geno_df.isna()
        has_missing = is_missing.any().any()

        # 所有非缺失的基因型
        valid_genos = sorted(geno_df[~is_missing].stack().unique())
        n_genos = len(valid_genos)

        # ---------- 4. 创建柔和颜色映射 + 缺失黑色 ----------
        # 柔和颜色：低饱和度、高明度
        saturation = 0.35
        value = 0.9
        hues = linspace(0, 1, n_genos, endpoint=False)
        soft_colors = [hsv_to_rgb((h, saturation, value)) for h in hues]

        # 若存在缺失值，在颜色列表末尾添加黑色
        if has_missing:
            soft_colors.append((0.0, 0.0, 0.0))  # 黑色
            missing_idx = n_genos  # 缺失值的索引
        else:
            missing_idx = -1

        cmap = ListedColormap(soft_colors)
        cmap.set_bad(color="white")  # 实际不会被用到，保留以防万一

        # 基因型到整数的映射
        genotype_to_int = {g: i for i, g in enumerate(valid_genos)}

        # ---------- 5. 构建数值矩阵 ----------
        def encode(geno):
            geno_str = str(geno)
            if geno_str.lower() in ["", "nan", "none"] or isna(geno):
                return missing_idx if has_missing else -1
            return genotype_to_int.get(geno_str, -1)

        int_matrix = geno_df.applymap(encode).values.astype(float)
        # 若存在缺失，不再mask，直接显示黑色；若无缺失，也不会出现-1
        # 为安全起见，将-1仍视为缺失但本例中若has_missing为False，-1不会出现
        if not has_missing:
            # 没有缺失，但万一有未知值，mask掉显示白色
            masked_matrix = masked_where(int_matrix == -1, int_matrix)
        else:
            masked_matrix = int_matrix

        # ---------- 6. 绘图 ----------
        plt.rcParams['font.size'] = 14
        n_rows, n_cols = masked_matrix.shape
        fig_w = max(6, n_cols * 0.5)
        fig_h = max(4, min(n_rows * 0.08, 24))
        fig, ax = plt.subplots(figsize=(fig_w, fig_h))

        # 实际上使用整数索引绘图，设 vmin=-0.5, vmax=最大索引+0.5
        plot_vmax = n_genos if has_missing else n_genos - 1
        ax.imshow(
            masked_matrix,
            aspect="auto",
            cmap=cmap,
            interpolation="nearest",
            vmin=-0.5,
            vmax=plot_vmax + 0.5,
            origin="upper",
        )

        # ---------- 7. 轴标签 ----------
        ax.set_xticks(arange(n_cols))
        ax.set_xticklabels(sample_cols, rotation=60)

        if n_rows > 50:
            step = max(1, n_rows // 25)
            yticks = arange(0, n_rows, step)
            yticklabels = df["ID"].iloc[yticks].values
        else:
            yticks = arange(n_rows)
            yticklabels = df["ID"].values
        ax.set_yticks(yticks)
        ax.set_yticklabels(yticklabels)

        # ---------- 8. 图例（包含缺失黑色）----------
        legend_colors = [cmap(i) for i in range(n_genos)]
        legend_labels = list(valid_genos)
        if has_missing:
            legend_colors.append(cmap(n_genos))
            legend_labels.append("Missing data")
        patches = [mpatches.Patch(color=c, label=l) for c, l in zip(legend_colors, legend_labels)]
        ax.legend(
            handles=patches,
            bbox_to_anchor=(1.02, 1),
            loc="upper left",
            borderaxespad=0.0
        )

        plt.tight_layout()
        plt.savefig(output_file, dpi=300, bbox_inches="tight")
        plt.close()

    def filter_multi_group_genotypes(self, groups: List[List[str]]) -> DataFrame:
        """
        Based on the provided sample classification information,
        select the loci where the genotypes within the group are consistent
        but the genotypes between groups are not.
        """
        df = self.to_dataframe(index_col=0, sort_allele=True)

        # Extract all columns and handle missing values
        all_columns = [col for group in groups for col in group]
        df_clean = df.dropna(subset=all_columns).copy()

        # Check the internal consistency of each group
        group_conditions = []
        for group in groups:
            group_cond = df_clean[group].nunique(axis=1) == 1
            group_conditions.append(group_cond)

        all_group_cond = concat(group_conditions, axis=1).all(axis=1)

        # Create representative value columns for each group
        rep_cols = []
        for i, group in enumerate(groups):
            rep_col = f'rep_{i}'
            df_clean[rep_col] = df_clean[group[0]]
            rep_cols.append(rep_col)

        # Strictly check the mutuality between groups (pairwise comparison)
        distinct_cond = Series(True, index=df_clean.index)
        n_groups = len(groups)

        for i in range(n_groups):
            for j in range(i + 1, n_groups):
                # Check whether each group is different from the others
                distinct_cond = distinct_cond & (df_clean[rep_cols[i]] != df_clean[rep_cols[j]])

        result = df_clean[all_group_cond & distinct_cond]

        return result.drop(columns=rep_cols)

    def genotype_phenotype_anova_analysis(
        self,
        trait_file: str,
        trait_name: str,
        out_path: str = '.',
        mark_sample_list: Union[List[str], None] = None
    ) -> None:
        """
        Perform phenotypic association analysis (ANOVA) for the genotype of each locus in the input genotype matrix and visualize the results.
        """

        def apply_func(
            genotype: Series,
            trait: DataFrame,
        ) -> Series:
            site_id = genotype['ID']
            df = genotype[4:].to_frame('Genotype')
            df = concat([df, trait[trait_name]], axis=1)
            df.index.name = 'Sample'

            # Perform ANOVA using statsmodels
            model = ols(f'{trait_name} ~ C(Genotype)', data=df).fit()
            anova_results = anova_lm(model)
            F = anova_results['F'][0]
            p_value = anova_results['PR(>F)'][0]

            i = 0
            x_tick_labels = []
            for gt, grouped_df in df.groupby('Genotype'):
                df.loc[df.Genotype == gt, 'x'] = i

                plt.boxplot(
                    x=grouped_df[trait_name],
                    positions=[i],
                    medianprops={'color': 'black'}
                )

                plt.scatter(
                    x=[i for _ in range(len(grouped_df[trait_name]))],
                    y=grouped_df[trait_name]
                )

                x_tick_labels.append(gt)
                i += 1

            if mark_sample_list:
                mark_sample_df = df.loc[mark_sample_list].sort_values(by=trait_name)
                mark_sample_df['Diff'] = mark_sample_df[trait_name].diff()
                mark_sample_df.fillna(0, inplace=True)
                mark_sample_df.loc[mark_sample_df.Diff < 1, 'dy'] = mark_sample_df['Diff'].max() / 10
                mark_sample_df.loc[mark_sample_df.Diff >= 1, 'dy'] = -mark_sample_df['Diff'].max() / 10
                plt.scatter(
                    x='x',
                    y=trait_name,
                    c='r',
                    data=mark_sample_df
                )

                for sample in mark_sample_list:
                    arrow_x = mark_sample_df.loc[sample]['x']
                    arrow_y = mark_sample_df.loc[sample][trait_name]
                    dy = mark_sample_df.loc[sample]['dy']
                    plt.arrow(
                        x=arrow_x,
                        y=arrow_y,
                        dx=0.3,
                        dy=dy,
                        linestyle='--',
                        linewidth=0.6,
                        color='r',
                        width=0,
                        head_width=0
                    )

                    plt.text(
                        x=arrow_x + 0.31,
                        y=arrow_y + dy,
                        s=sample,
                        fontsize=8,
                        color='r'
                    )

            plt.xticks(range(len(x_tick_labels)), x_tick_labels)
            title = plt.title(f'site: {site_id}\ntrait: {trait_name}\nF: {F:.3f}  p value: {p_value:.4f}')
            title.set_linespacing(1.73)  # 1.73 times line spacing
            plt.savefig(f'{out_path}/{site_id}_{trait_name}.png', dpi=150, bbox_inches='tight')
            plt.savefig(f'{out_path}/{site_id}_{trait_name}.pdf', dpi=150, bbox_inches='tight')
            plt.cla()

            result = Series(
                data=[site_id, trait_name, F, p_value],
                index=['ID', 'Trait', 'F', 'P_value']
            )
            return result

        makedirs(out_path, exist_ok=True)
        plt.rcParams['font.size'] = 12

        trait_df = read_csv(trait_file, sep='\t').groupby('ID').mean()
        ret = self.to_dataframe(index_col=None, sort_allele=False).apply(partial(apply_func,trait=trait_df), axis=1)
        ret.to_csv(f'{out_path}/site_sig_stats.xls', sep='\t', na_rep='NA', index=False)

    def select_core_snps_ga(
        self,
        min_per_chrom: Optional[int] = None,
        pop_size: int = 100,
        max_gen: int = 500,
        cross_prob: float = 0.8,
        mut_prob: float = 0.05,
        elite_count: int = 2,
        seed: Optional[int] = None,
        no_elimination: bool = False,
        output_curve: bool = True,
        curve_prefix: str = "identification_rate_curve"
    ) -> DataFrame:
        r"""
        Select a minimal core set of SNP loci that can fully discriminate all samples
        using a genetic algorithm (GA) with optional uniform chromosomal distribution
        constraints.

        The method first encodes genotypes into numerical values (0 for reference
        homozygote, 1 for heterozygote, 2 for alternative homozygote). It then
        performs a genetic algorithm search over binary chromosomes (1 = selected SNP)
        with a hierarchical fitness function that prioritizes sample discrimination,
        followed by uniform interval coverage across chromosomes if `min_per_chrom`
        is specified. After GA convergence, an optional backward elimination step
        greedily removes redundant SNPs while preserving full discrimination and
        constraint satisfaction. Finally, an identification rate curve is generated
        by forward selection, showing how the discrimination rate improves as more
        SNPs from the core set are added.

        Args:
            min_per_chrom (Optional[int]):
                If provided, enforce that each chromosome is divided into this many
                uniform intervals (based on physical positions) and that at least one
                SNP is selected from every interval. Set to `None` to disable this
                constraint.
            pop_size (int):
                Population size for the genetic algorithm. Default: 100.
            max_gen (int):
                Maximum number of generations to run the GA. Default: 500.
            cross_prob (float):
                Crossover probability (0–1). Default: 0.8.
            mut_prob (float):
                Per-bit mutation probability (0–1). Default: 0.05.
            elite_count (int):
                Number of top-fit individuals to preserve unchanged in each generation.
                Default: 2.
            seed (Optional[int]):
                Random seed for reproducibility. Default: None.
            no_elimination (bool):
                If True, skip the backward elimination step after GA. Default: False.
            output_curve (bool):
                If True, generate a forward-selection curve of identification rate
                vs. number of SNPs and save both data (.txt) and figure (.pdf).
                Default: True.
            curve_prefix (str):
                Prefix for output curve files (e.g., "my_curve" produces
                `my_curve.txt` and `my_curve.pdf`). Default: "identification_rate_curve".

        Returns:
            pandas.DataFrame:
                A DataFrame containing all original columns (ID, Chrom, Position, Ref,
                and all sample columns) for the selected core SNPs. Rows are sorted
                by chromosome and position.

        Raises:
            ValueError:
                If the input DataFrame does not contain the required metadata columns
                ('ID', 'Chrom', 'Position', 'Ref'), or if genotype strings have an
                unexpected length, or if fewer than two samples are present.
            RuntimeError:
                If the uniform interval constraint cannot be satisfied (e.g., a
                chromosome interval contains no candidate SNPs).

        Notes:
            - The fitness function is layered:
                1. If not all samples are distinguished, fitness = (#distinguished) / (total samples).
                2. If all samples are distinguished but interval constraints are not met,
                   fitness = 1.0 + (covered_intervals) / (total_intervals).
                3. If all samples are distinguished and all intervals are covered,
                   fitness = 2.0 + 1.0 / (selected_count + 1), which favors smaller sets.
            - Backward elimination is only performed when the GA solution achieves
              full discrimination and (if constraints are active) satisfies them.
            - The identification curve is generated by greedily adding the SNP that
              most improves the discrimination rate at each step, starting from the
              core set returned by the GA.

        Example:
            >>> gt = GenoType("snp_matrix.tsv")
            >>> core = gt.select_core_snps_ga(min_per_chrom=10, pop_size=150, seed=42)
            >>> core.to_csv("core_snps.tsv", sep="\t", index=False)
        """
        if seed is not None:
            random.seed(seed)

        # 1. 读取完整数据（保留所有列，不设置索引）
        df = self.to_dataframe(index_col=None, sort_allele=True)
        # 确保前4列为 ID, Chrom, Position, Ref
        meta_cols = ['ID', 'Chrom', 'Position', 'Ref']
        if not all(col in df.columns for col in meta_cols):
            raise ValueError("Genotype file must including four coulmns: 'ID', 'Chrom', 'Position', and 'Ref'.")
        sample_cols = [c for c in df.columns if c not in meta_cols]
        if len(sample_cols) < 2:
            raise ValueError("At least two samples are required for variety differentiation.")

        # 2. 数据清洗：删除包含缺失值的SNP行（防止编码出错）
        df_clean = df.dropna(subset=sample_cols).copy()
        if len(df_clean) < len(df):
            echo(
                message=f"\033[33mWarring：{len(df) - len(df_clean)} SNP containing missing genotypes were removed.\033[0m",
                err=True
            )
        df = df_clean.reset_index(drop=True)

        n_snps = len(df)
        n_samples = len(sample_cols)

        # 3. 构建编码矩阵 (0/1/2)
        # 提取ref和所有样本基因型
        refs = df['Ref'].values
        geno_matrix = []  # n_snps x n_samples
        snp_ids = df['ID'].tolist()
        chroms = df['Chrom'].astype(str).tolist()
        positions = df['Position'].astype(int).tolist()

        for idx, row in df.iterrows():
            ref = row['Ref']
            # 收集所有等位基因（用于确定alt）
            alleles = set()
            for sample in sample_cols:
                gt = str(row[sample])
                if len(gt) != 2:
                    raise ValueError(f"SNP {row['ID']} genotype length is not 2: {gt}")
                alleles.add(gt[0])
                alleles.add(gt[1])
            if ref not in alleles:
                raise ValueError(f"SNP {row['ID']} reference allele {ref} was not found in the sample.")
            alt = ref if len(alleles) == 1 else (alleles - {ref}).pop()
            # 编码
            code = []
            for sample in sample_cols:
                gt = str(row[sample])
                a1, a2 = gt[0], gt[1]
                if a1 == ref and a2 == ref:
                    code.append(0)
                elif (a1 == ref and a2 == alt) or (a1 == alt and a2 == ref):
                    code.append(1)
                elif a1 == alt and a2 == alt:
                    code.append(2)
                else:
                    raise ValueError(f"SNP {row['ID']} genotype {gt} cannot be encoded.")
            geno_matrix.append(code)

        chrom_set = sorted(set(chroms), key=lambda c: (c.isdigit(), int(c) if c.isdigit() else c))

        # 4. 构建bin映射（若min_per_chrom不为None）
        bin_of_snp = None
        if min_per_chrom is not None:
            bin_of_snp = self.__build_bin_map(chroms, positions, chrom_set, min_per_chrom)
            if bin_of_snp is None:
                raise RuntimeError(
                    "The uniform distribution constraint cannot be met. "
                    "Please adjust min_per_chrom or check the SNP distribution of the chromosomes."
                )

        # 5. 遗传算法
        echo(
            message=f"\033[32mSample size：{n_samples}\nCandidate SNP size：{n_snps}\nNumber of chromosome：{len(chrom_set)}\n\033[0m",
            err=True
        )
        if min_per_chrom is not None:
            echo(
                message=f"\033[36mEnable uniform distribution constraints. Each chromosome is equally divided into {min_per_chrom} intervals.\033[0m",
                err=True
            )

        population = self.__init_population(pop_size, n_snps)
        best_solution = None
        best_fitness = 0.0
        best_k = float('inf')

        for gen in range(max_gen):
            fitnesses = [
                self.__evaluate(
                    ind,
                    geno_matrix,
                    n_samples,
                    chroms,
                    chrom_set,
                    min_per_chrom,
                    bin_of_snp
                )
                for ind in population
            ]
            for ind, fit in zip(population, fitnesses):
                if fit > best_fitness:
                    best_fitness = fit
                    best_solution = ind[:]
                    if fit > 1.0:
                        best_k = sum(ind)

            sorted_idx = sorted(range(len(fitnesses)), key=lambda i: fitnesses[i], reverse=True)
            new_pop = [population[i][:] for i in sorted_idx[:elite_count]]
            while len(new_pop) < pop_size:
                p1, p2 = self.__tournament_select(population, fitnesses)
                off1, off2 = self.__crossover(p1, p2, cross_prob)
                self.__mutate(off1, mut_prob)
                self.__mutate(off2, mut_prob)
                new_pop.append(off1)
                if len(new_pop) < pop_size:
                    new_pop.append(off2)
            population = new_pop

            if gen % 50 == 0:
                state = "unknown"
                if best_fitness >= 2.0:
                    state = f"complete distinction and constraint satisfaction ({best_k} SNPs)"
                elif best_fitness >= 1.0:
                    state = "the distinction is complete but the constraints are not fully satisfied"
                else:
                    state = f"discrimination {best_fitness * n_samples:.0f}/{n_samples}"
                echo(f"Generation {gen}: fitness {best_fitness:.4f}, {state}", err=True)

        # 6. 后向删除
        selected_indices = [i for i, bit in enumerate(best_solution) if bit == 1]
        if best_fitness >= 1.0 and not no_elimination:
            if min_per_chrom is not None and best_fitness < 2.0:
                echo(
                    message="\n\033[33mWarning：The current solution does not satisfy the uniform distribution constraint and skip the backward deletion.\033[0m",
                    err=True
                )
                core_indices = selected_indices
            else:
                echo("\n\033[36mPerforming backward deletion...\033[0m", err=True)
                core_indices = self.__backward_elimination(
                    selected_indices,
                    geno_matrix,
                    n_samples,
                    chroms,
                    min_per_chrom,
                    bin_of_snp
                )
        else:
            core_indices = selected_indices

        core_snps = [snp_ids[i] for i in core_indices]

        echo(message="\n\033[36m===== The final core SNP combination =====\033[0m", err=True)
        echo(message=f"\033[32mTotal SNPs：{len(core_snps)}\033[0m", err=True)
        # 按染色体输出分布
        chrom_snps = defaultdict(list)
        for idx in core_indices:
            chrom_snps[chroms[idx]].append(snp_ids[idx])
        for chrom in chrom_set:
            echo(message=f"\033[32m  Chromosome {chrom}: {len(chrom_snps[chrom])} SNPs\033[0m", err=True)

        # 验证区分度
        fingerprints = {}
        conflict = False
        for s_idx, sample_name in enumerate(sample_cols):
            fp = tuple(geno_matrix[i][s_idx] for i in core_indices)
            if fp in fingerprints:
                echo(message=f"\033[33mConflict：The fingerprints of {fingerprints[fp]} and {sample_name} are same.\n\033[0m", err=True)
                conflict = True
            else:
                fingerprints[fp] = sample_name
            if not conflict:
                echo(message="All the sample fingerprints are unique and can be completely distinguished.\n", err=True)

        # 7. 品种识别率曲线分析（基于核心位点集）
        if output_curve:
            echo("\n\033[36m===== Analysis of the variety identification rate curve =====\n\033[0m", err=True)
            snps_num, rec_rates = self.__forward_selection_curve(core_indices, geno_matrix, n_samples)
            # 保存数据
            with open(f"{curve_prefix}.txt", "w") as f:
                f.write("SNP_count\tIdentification_rate\n")
                for k, r in zip(snps_num, rec_rates):
                    f.write(f"{k}\t{r:.4f}\n")

            # 打印关键节点
            for i, (k, r) in enumerate(zip(snps_num, rec_rates)):
                if r == 1.0:
                    echo(message=f"\033[32mThe minimum number of SNPS required to achieve a 100% recognition rate is {k}.\033[0m", err=True)
                    break
            else:
                echo(
                    message=f"Using all {len(core_indices)} core SNPs failed to achieve a 100% recognition rate. Current recognition rate {rec_rates[-1]:.4f}",
                    err=True
                )

            # 可视化
            self.__plot_identification_curve(snps_num, rec_rates, f"{curve_prefix}.pdf")
            self.__plot_identification_curve(snps_num, rec_rates, f"{curve_prefix}.png")

        # 8. 返回选中SNP的完整DataFrame（包含所有列）
        result_df = df.iloc[core_indices].copy()
        # 按染色体、位置排序
        result_df['Position'] = result_df['Position'].astype(int)
        result_df.sort_values(['Chrom', 'Position'], key=natsort_key, inplace=True)
        result_df.reset_index(drop=True, inplace=True)
        return result_df

    # ---------- 遗传算法辅助静态方法 ----------
    @staticmethod
    def __build_bin_map(chroms, positions, chrom_set, min_per_chrom):
        """为每条染色体等分区间，返回每个SNP的bin索引，若某区间无SNP则返回None"""
        bin_of_snp = [-1] * len(chroms)
        for chrom in chrom_set:
            idxs = [i for i, c in enumerate(chroms) if c == chrom]
            if len(idxs) == 0:
                continue
            pos_list = [positions[i] for i in idxs]
            min_pos, max_pos = min(pos_list), max(pos_list)
            n_bins = min_per_chrom
            if max_pos == min_pos:
                echo(
                    message=f"\033[33mWarning：Chromosome {chrom} all SNPS are in the same position ({min_pos}), it is impossible to divide the {n_bins} uniform intervals!",
                    err=True
                )
                return None
            for idx in idxs:
                pos = positions[idx]
                bin_idx = int((pos - min_pos) / (max_pos - min_pos) * n_bins)
                if bin_idx == n_bins:
                    bin_idx = n_bins - 1
                bin_of_snp[idx] = bin_idx
            # 检查区间是否都有SNP
            bin_counts = [0] * n_bins
            for idx in idxs:
                bin_counts[bin_of_snp[idx]] += 1
            if any(cnt == 0 for cnt in bin_counts):
                empty = [i for i, c in enumerate(bin_counts) if c == 0]
                echo(
                    message=f"\033[33mWarning：There are no candidate SNPs in the interval {empty} of chromosome {chrom}, which fails to meet the constraints!",
                    err=True
                )
                return None
        return bin_of_snp

    @staticmethod
    def __evaluate(chromosome, geno_matrix, n_samples, chroms, chrom_set, min_per_chrom, bin_of_snp):
        """分层适应度：区分度<1，完全区分+约束不满足1~2，完全区分+约束满足≥2"""
        selected = [i for i, bit in enumerate(chromosome) if bit == 1]
        k = len(selected)
        if k == 0:
            return 0.0

        # 区分度检查
        fingerprints = {}
        for s in range(n_samples):
            fp = tuple(geno_matrix[i][s] for i in selected)
            if fp in fingerprints:
                return len(fingerprints) / n_samples
            fingerprints[fp] = s

        # 完全区分，检查约束
        if min_per_chrom is None:
            return 2.0 + 1.0 / (k + 1)

        # 统计每条染色体每个bin是否被覆盖
        chrom_bin_covered = {c: set() for c in chrom_set}
        for idx in selected:
            c = chroms[idx]
            b = bin_of_snp[idx]
            chrom_bin_covered[c].add(b)
        total_bins = len(chrom_set) * min_per_chrom
        covered = sum(len(bins) for bins in chrom_bin_covered.values())
        if covered == total_bins:
            return 2.0 + 1.0 / (k + 1)
        else:
            return 1.0 + covered / total_bins

    @staticmethod
    def __init_population(pop_size, n_snps):
        return [[1 if random.random() < 0.3 else 0 for _ in range(n_snps)] for _ in range(pop_size)]

    @staticmethod
    def __tournament_select(population, fitnesses, tournament_size=3):
        selected = []
        for _ in range(2):
            candidates = random.sample(list(zip(population, fitnesses)), tournament_size)
            winner = max(candidates, key=lambda x: x[1])[0]
            selected.append(winner[:])
        return selected

    @staticmethod
    def __crossover(parent1, parent2, pc=0.8):
        if random.random() < pc:
            point = random.randint(1, len(parent1) - 1)
            return parent1[:point] + parent2[point:], parent2[:point] + parent1[point:]
        return parent1[:], parent2[:]

    @staticmethod
    def __mutate(chromosome, pm=0.05):
        for i in range(len(chromosome)):
            if random.random() < pm:
                chromosome[i] = 1 - chromosome[i]

    @staticmethod
    def __backward_elimination(
        selected_indices,
        geno_matrix,
        n_samples,
        chroms,
        min_per_chrom,
        bin_of_snp
    ):
        """贪心删除冗余SNP，保持完全区分及均匀区间约束"""
        current = set(selected_indices)
        # bin -> snp 索引映射
        bin_to_snps = defaultdict(lambda: defaultdict(set))
        for idx in current:
            c = chroms[idx]
            b = bin_of_snp[idx] if min_per_chrom else 'all'
            bin_to_snps[c][b].add(idx)

        changed = True
        while changed:
            changed = False
            for idx in list(current):
                c = chroms[idx]
                b = bin_of_snp[idx] if min_per_chrom else 'all'
                if len(bin_to_snps[c][b]) <= 1:
                    continue
                test_set = current - {idx}
                # 检查是否还能完全区分
                fingerprints = {}
                conflict = False
                for s in range(n_samples):
                    fp = tuple(geno_matrix[i][s] for i in test_set)
                    if fp in fingerprints:
                        conflict = True
                        break
                    fingerprints[fp] = s
                if not conflict:
                    current = test_set
                    bin_to_snps[c][b].remove(idx)
                    changed = True
                    break
        return sorted(current)

    @staticmethod
    def __calc_distinguish_rate(selected_idx, geno_matrix, n_samples):
        fingerprints = {}
        for s in range(n_samples):
            fp = tuple(geno_matrix[i][s] for i in selected_idx)
            fingerprints[fp] = s
        return len(fingerprints) / n_samples

    @staticmethod
    def __forward_selection_curve(candidate_indices, geno_matrix, n_samples):
        """
        从候选位点中逐次加入最提升区分度的SNP，返回 (SNP数量列表, 识别率列表)
        """
        selected = []
        remaining = set(candidate_indices)
        rates = []
        snps_count = []
        current_rate = 0.0
        while remaining and current_rate < 1.0:
            best_idx = None
            best_rate = current_rate
            for idx in remaining:
                test_set = selected + [idx]
                rate = GenoType.__calc_distinguish_rate(test_set, geno_matrix, n_samples)
                if rate > best_rate:
                    best_rate = rate
                    best_idx = idx
            if best_idx is None:
                break
            selected.append(best_idx)
            remaining.remove(best_idx)
            current_rate = best_rate
            snps_count.append(len(selected))
            rates.append(current_rate)
        return snps_count, rates

    @staticmethod
    def __plot_identification_curve(snps_num, rates, output_img='identification_rate_curve.pdf'):
        """绘制识别率曲线并保存"""
        plt.rcParams['font.size'] = 14
        plt.figure(figsize=(8, 5))
        plt.plot(snps_num, [r * 100 for r in rates], marker='o', linestyle='-', color='#2c7bb6')
        plt.xlabel('Number of SNPs', fontsize=12)
        plt.ylabel('Identification Rate (%)', fontsize=12)
        plt.title('Variety Identification Rate vs. Number of Selected SNPs', fontsize=14)
        plt.grid(True, linestyle='--', alpha=0.6)
        # 标注100%位置
        for i, (k, r) in enumerate(zip(snps_num, rates)):
            if r == 1.0:
                plt.axvline(
                    x=k,
                    color='red',
                    linestyle='--',
                    alpha=0.7,
                    label=f'100% at {k} SNPs'
                )
                plt.legend()
                break
        plt.tight_layout()
        plt.savefig(output_img, dpi=200)
        plt.close()