"""
File: check_yml.py
Description: Check params in yml file.
CreateDate: 2026/3/1
Author: xuwenlin
E-mail: wenlinxu.njfu@outlook.com
"""
from io import TextIOWrapper
from os import access, W_OK
from os.path import isfile, isdir, dirname
from yaml import safe_load
from schema import Schema, SchemaError
from click import echo


def is_valid_file(path: str):
    if not isfile(path):
        raise ValueError(f"No such file: {path}")
    return path


def is_valid_directory(path: str):
    if not isdir(path):
        raise ValueError(f"No such directory: {path}")
    return path


def is_writable(path: str):
    if isdir(path):
        check_path = path
    else:
        check_path = dirname(path)
    if not access(check_path, W_OK):
        raise ValueError(f"The path cannot be written: {path}")
    return path


def check_config(module_dict:dict, yaml_file: TextIOWrapper):
    echo('\033[36mCheck params.\033[0m', err=True)
    config_schema = Schema(module_dict)

    config = safe_load(yaml_file)
    try:
        config_schema.validate(config)
        echo("\033[32mConfiguration verification passed.\n\033[0m", err=True)
    except SchemaError as e:
        echo(f"\033[31mConfig error: {e}\033[0m", err=True)
        exit()
    else:
        return config